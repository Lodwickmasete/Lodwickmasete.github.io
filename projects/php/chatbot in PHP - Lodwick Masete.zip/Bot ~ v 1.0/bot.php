<?php
session_start();

// Set session name to "Lodwick"
$_SESSION['name'] = "Lodwick";

// Get the user's message
$userMessage = strtolower($_POST['message']);

// Load triggers from the JSON file
$triggersJsonFile = 'triggers.json'; 
$triggersJson = file_get_contents($triggersJsonFile);
$triggers = json_decode($triggersJson, true);

// Process the user's message and generate a response
$botResponse = generateResponse($userMessage, $triggers);

// Simulate processing time
sleep(1);

// Send the response
echo $botResponse;

// Function to generate bot response based on user input
function generateResponse($userMessage, $triggers) {
    // Define topics and their corresponding questions
    $topics = [
        "coding" => [
            "Do you love coding?" => [
                "yes" => "Okay cool",
                "no" => "What don't you like about coding?"
            ],
            "Do you enjoy programming?" => [
                "yes" => "Great!",
                "no" => "That's okay. Programming isn't for everyone."
            ],
            "What's your first program?" => [
                "default" => "I thought you'd choose from yes or no."
            ]
        ],
        "music" => [
            "Do you like music?" => [
                "yes" => "Awesome!",
                "no" => "Oh, that's too bad. Music can be so uplifting."
            ],
            "Favorite music genre?" => [
                "default" => "I see. What's your favorite song?"
            ]
        ]
    ];

    // Retrieve user's name from session if available
    $userName = isset($_SESSION['name']) ? $_SESSION['name'] : '';

    // Debugging log for checked keywords
    $debugLog = '';

    // Check if there's a topic and question in the session
    if (isset($_SESSION['topic']) && isset($_SESSION['question'])) {
        $topic = $_SESSION['topic'];
        $question = $_SESSION['question'];

        // Check if user wants to change the topic
        if (strpos($userMessage, "change topic") !== false) {
            // Clear the session variables for topic and question
            unset($_SESSION['topic']);
            unset($_SESSION['question']);
            logChat($userMessage, "Sure, let's change the topic. What would you like to talk about?");
            return "Sure, let's change the topic. What would you like to talk about?";
        }

        // Check if the user's response matches any options for the current question
        if (isset($topics[$topic][$question][$userMessage])) {
            $response = $topics[$topic][$question][$userMessage];

            // If there's a response, find the next question in the topic
            $nextQuestion = getNextQuestion($topic, $question, $topics);
            if ($nextQuestion !== null) {
                $_SESSION['question'] = $nextQuestion;
                logChat($userMessage, $response . " " . $nextQuestion);
                return $response . " " . $nextQuestion;
            } else {
                // If no more questions in the topic, clear the session variables
                unset($_SESSION['topic']);
                unset($_SESSION['question']);
                logChat($userMessage, $response);
                return $response;
            }
        }
    }

    // Check if the user's message matches any predefined triggers
    $matchedResponses = [];
foreach ($triggers as $trigger) {
    foreach ($trigger['keywords'] as $keyword) {
        // Debugging: Log checked keyword against user's message
        $debugLog .= "Checking keyword: '$keyword' in user message: '$userMessage'<br>";

        // Adjust the condition to directly check for the keyword
        if (stripos($userMessage, $keyword) !== false) {
            // Randomly select one response from the available responses
            $randomResponse = $trigger['answers'][array_rand($trigger['answers'])];
            $matchedResponses[] = sprintf($randomResponse, $userName);
            break; // Exit inner loop once a match is found
        }
    }
}



    // Check if the user's message includes mention of any topic
    foreach ($topics as $topic => $questions) {
        if (strpos($userMessage, $topic) !== false) {
            // If topic is mentioned, start with the first question related to the topic
            $firstQuestion = array_keys($questions)[0];
            $_SESSION['topic'] = $topic;
            $_SESSION['question'] = $firstQuestion;
            $matchedResponses[] = $firstQuestion;
        }
    }

// If triggers matched, combine responses with <p> tags
if (!empty($matchedResponses)) {
    $response = implode("<p>", $matchedResponses);
} else {
    // If no triggers match, generate a random apology message
    $apologyMessages = [
        "I'm sorry, I couldn't understand that.",
        "Oops! It seems I'm not familiar with that topic.",
        "My apologies, I didn't catch that. Let's try something else.",
        "Sorry, I couldn't find a relevant response.",
        "Hmm, it seems I'm a bit lost. Can you try something else?"
    ];
    $response = $apologyMessages[array_rand($apologyMessages)];
}
    // Combine the matched responses into a single string separated by <br> tag
    $response = implode("<br>", $matchedResponses);

    // Log chat interaction
    logChat($userMessage, $response);

    // Append debugging log to HTML file
    appendToDebugLog($debugLog);

    return $response;
}

// Function to get the next question in a topic
function getNextQuestion($topic, $currentQuestion, $topics) {
    $questions = array_keys($topics[$topic]);
    $currentIndex = array_search($currentQuestion, $questions);
    if ($currentIndex !== false && isset($questions[$currentIndex + 1])) {
        return $questions[$currentIndex + 1];
    }
    return null; // No more questions in the topic
}

// Function to log chat interactions
function logChat($userMessage, $botResponse) {
    $userId = 2; // Assume the user id is 2 for now
    $directory = "chats/$userId";
    $logFile = "$directory/chatLog.txt";

    // Create directory if it doesn't exist
    if (!is_dir($directory)) {
        mkdir($directory, 0777, true);
    }

    // Log the chat messages
    $logMessage = "[" . $_SESSION['name'] . "] " . "$userMessage\n[bot] $botResponse\n";
    file_put_contents($logFile, $logMessage, FILE_APPEND);
}

// Function to append debug log to debugging.html
function appendToDebugLog($debugLog) {
    $debugFile = "debugging.html";
    $debugMessage = "<hr><h3>Debug Log:</h3>$debugLog";

    // Append debug message to the debug file
    file_put_contents($debugFile, $debugMessage, FILE_APPEND);
}
?>


