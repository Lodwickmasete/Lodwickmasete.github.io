<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Simple Chatbot</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f9f9f9;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    #chat-container {
        width: 100%;
        height: 100vh;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        overflow: hidden;
        display: flex;
        flex-direction: column;
    }

    #chat-box {
        flex: 1;
        overflow-y: auto;
        padding: 10px;
    }

    .message {
        padding: 8px 12px;
        margin-bottom: 10px;
        border-radius: 5px;
        max-width: 80%;
    }

    .user-message {
        align-self: flex-end;
        border-radius: 1.125rem 1.125rem 0 1.125rem;
        color: black;
        box-sizing: border-box;
        background: #FFF;
        min-height: 2.25rem;
        width: fit-content;
        max-width: 66%;
        background-color: gold;
        padding: 5px;
        margin: 1rem 1rem 1rem auto;
    }

    .bot-message {
        align-self: flex-start;
        border-radius: 1.125rem 1.125rem 0 1.125rem;
        background-color: black;
        color: white;
        box-sizing: border-box;
        padding: 0.5rem 1rem;
        margin: 1rem;
        border-radius: 1.125rem 1.125rem 1.125rem 0;
        min-height: 2.25rem;
        width: fit-content;
        max-width: 66%;
        box-shadow: 0 0 2rem rgba(0, 0, 0, 0.075), 0rem 1rem 1rem -1rem rgba(0, 0, 0, 0.1);
    }

    #user-input-container {
        display: flex;
        border-top: 1px solid #ccc;
    }

    input[type="text"] {
        flex: 1;
        padding: 25px;
        border: 1px solid #ccc;
        border-radius: 0;
        border-right: none;
    }

    button {
        width: 80px;
        padding: 8px;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 0;
        cursor: pointer;
    }

    button:hover {
        background-color: #0056b3;
    }
    

</style>
</head>
<body>

<div id="chat-container">
    <div id="chat-box">
        <?php
        $_SESSION['name'] = "Lodwick";

        $userId = 2; // Assume the user id is 1 for now
        $logFile = "chats/$userId/chatLog.txt";

        if (file_exists($logFile)) {
            $chatLog = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            foreach ($chatLog as $line) {
                if (strpos($line, '['. $_SESSION['name'] .']') !== false) {
                    echo "<div class='message user-message'>" . htmlspecialchars(substr($line, 7)) . "</div>";
                } elseif (strpos($line, '[bot]') !== false) {
                    echo "<div class='message bot-message'>" . htmlspecialchars(substr($line, 6)) . "</div>";
                }
            }
        }
        ?>
    </div>
    <div id="suggestion">

    </div>  
    <div id="user-input-container">

        <input type="text" id="user-input" placeholder="Type your message...">
        <button onclick="sendMessage()">Send</button>
    </div>
</div>

<script>
    function sendMessage() {
        var userInput = document.getElementById("user-input").value;
        if (userInput.trim() === "") {
            return;
        }

        var chatBox = document.getElementById("chat-box");
        var userMessage = "<div class='message user-message'>" + userInput + "</div>";
        chatBox.innerHTML += userMessage;

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                var botResponse = "<div class='message bot-message'>" + this.responseText + "</div>";
                chatBox.innerHTML += botResponse;
                chatBox.scrollTop = chatBox.scrollHeight;
                document.getElementById("user-input").value = "";
            }
        };
        xhttp.open("POST", "bot.php", true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send("message=" + encodeURIComponent(userInput));
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    window.onload = function() {
        var chatBox = document.getElementById("chat-box");
        chatBox.scrollTop = chatBox.scrollHeight;
    };
</script>

</body>
</html>