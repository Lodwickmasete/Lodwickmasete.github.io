-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 31, 2024 at 05:01 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Construction`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`log_id`, `user_id`, `action`, `created_at`) VALUES
(1, 1, 'Service running', '2024-08-01 06:47:37'),
(2, 1, 'Server booted', '2024-08-01 06:47:37'),
(3, 4, 'New User registered', '2024-08-02 13:23:54'),
(4, 2, 'Booking created', '2024-08-02 13:27:10'),
(5, 2, 'Booking created', '2024-08-02 14:38:58'),
(6, 2, 'Booking created', '2024-08-02 15:11:04'),
(7, 1, 'Booking created', '2024-08-02 16:53:46'),
(8, 1, 'Booking created', '2024-08-02 16:54:49'),
(9, 1, 'Booking created', '2024-08-02 16:54:56'),
(10, 6, 'New User registered', '2024-08-02 17:27:50'),
(11, 7, 'New User registered', '2024-08-02 17:29:05');

-- --------------------------------------------------------

--
-- Table structure for table `approved_books`
--

CREATE TABLE `approved_books` (
  `booking_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `authentication`
--

CREATE TABLE `authentication` (
  `id` int(255) NOT NULL,
  `admin_book_ref` varchar(255) DEFAULT NULL,
  `user_book_ref` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `authentication`
--

INSERT INTO `authentication` (`id`, `admin_book_ref`, `user_book_ref`, `role`) VALUES
(1, '004', NULL, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `details` text NOT NULL,
  `booking_date` date NOT NULL,
  `status` varchar(20) DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`booking_id`, `user_id`, `details`, `booking_date`, `status`, `created_at`, `updated_at`) VALUES
(6, 1, 'Hey', '2024-08-02', 'Pending', '2024-08-02 16:53:45', '2024-08-02 16:53:45'),
(9, 1, '6', '2024-08-02', 'Pending', '2024-08-02 16:54:56', '2024-08-02 16:54:56'),
(10, 2, 'Tt5', '2024-08-02', 'Pending', '2024-08-02 17:47:06', '2024-08-02 17:47:06');

-- --------------------------------------------------------

--
-- Table structure for table `declined_books`
--

CREATE TABLE `declined_books` (
  `booking_id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'johndoe', 'john.doe@example.com', 'hashed_password', 1, '2024-08-01 06:47:37', '2024-08-01 06:47:37'),
(2, 'Lodwick', 'Lodwick@example.com', 'hashed_password', 1, '2024-08-01 06:47:37', '2024-08-01 06:47:37'),
(4, 'root', 'infonnako@gmail.com', '$2y$10$096yCdWKMemEVPwCMCXs8e46/YoqzLEF./yRbvmX72FT.teyZo4mi', 1, '2024-08-02 13:23:54', '2024-08-02 13:23:54'),
(6, '', 'infonnak1o@gmail.com', '$2y$10$VLuRrS1ULc/Yp4/y1Z/RSOpgOLP0GdoqaptIUapDVlhd/svP3kpwq', 1, '2024-08-02 17:27:50', '2024-08-02 17:27:50'),
(7, 'Hh', 'infonhnako@gmail.com', '$2y$10$48cV6zKnXGArqNuITBpnEuVNpbRDZM0eLeY06LyCiySV4CFT4EvMW', 1, '2024-08-02 17:29:05', '2024-08-02 17:29:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `authentication`
--
ALTER TABLE `authentication`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `authentication`
--
ALTER TABLE `authentication`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD CONSTRAINT `activity_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
