<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Management</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mx-auto mt-10">

<?php
include 'db_conn.php'; // Include your database connection file

// Fetch Existing Bookings for Display
$sql = "SELECT * FROM bookings";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td class='px-4 py-3'>" . $row["booking_id"] . "</td>";
        echo "<td class='px-4 py-3'>" . $row["user_id"] . "</td>";
        echo "<td class='px-4 py-3'>" . $row["details"] . "</td>";
        echo "<td class='px-4 py-3'>" . $row["booking_date"] . "</td>";
        echo "<td class='px-4 py-3'>" . $row["status"] . "</td>";
        echo "<td class='px-4 py-3'>";
        echo "<form method='POST' action='book_action.php'>";
        echo "<input type='hidden' name='booking_id' value='" . $row["booking_id"] . "'>";
        echo "<button type='submit' name='approve' class='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded'>Approve</button>";
        echo "<button type='submit' name='decline' class='bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded ml-2'>Decline</button>";
        echo "</form>";
        echo "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6' class='px-4 py-3 text-center'>No bookings found.</td></tr>";
}

$conn->close();
?>
    </div>
</body>
</html>