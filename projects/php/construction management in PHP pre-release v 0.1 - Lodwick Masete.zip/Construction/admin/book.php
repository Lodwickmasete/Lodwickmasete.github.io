<?php
 if (!isset($_POST["ref"])){ 
exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="flex justify-center items-center h-screen bg-gray-100">

    <form class="bg-white p-6 rounded shadow-md" method="POST" action="queries/process_book.php">

        <h2 class="text-2xl mb-4">Create Booking</h2>
        <label class="block mb-2">User ID:</label>
        <input class="border w-full p-2 mb-4" type="number" name="user_id" required>
        <label class="block mb-2">Details:</label>
        <textarea class="border w-full p-2 mb-4" name="details" required></textarea>
        <label class="block mb-2">Booking Date:</label>
        <input class="border w-full p-2 mb-4" type="date" name="booking_date" required>
        <button class="bg-blue-500 text-white px-4 py-2 rounded" type="submit">Create Booking</button>
    </form>
</body>
</html>