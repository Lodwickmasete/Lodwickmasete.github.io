<?php
include 'db_conn.php';

// Handle New Booking Creation
if (isset($_POST['create_booking'])) {
    $user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
    $details = mysqli_real_escape_string($conn, $_POST['details']);
    $booking_date = mysqli_real_escape_string($conn, $_POST['booking_date']);

    $sql = "INSERT INTO bookings (user_id, details, booking_date) VALUES ('$user_id', '$details', '$booking_date')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Booking created successfully!');</script>";
    } else {
        echo "<script>alert('Error creating booking: " . $conn->error . "');</script>";
    }
}

// Handle Approve/Decline Actions
if (isset($_POST['approve']) || isset($_POST['decline'])) {
    $booking_id = mysqli_real_escape_string($conn, $_POST['booking_id']);

    if (isset($_POST['approve'])) {
        // Move to approved_books
        $sql = "INSERT INTO approved_books SELECT * FROM bookings WHERE booking_id = $booking_id";
        $conn->query($sql);

        // Delete from bookings table
        $sql = "DELETE FROM bookings WHERE booking_id = $booking_id";
        $conn->query($sql);

        echo "<script>alert('Booking approved!');</script>";
    } else if (isset($_POST['decline'])) {
        // Move to declined_books
        $sql = "INSERT INTO declined_books SELECT * FROM bookings WHERE booking_id = $booking_id";
        $conn->query($sql);

        // Delete from bookings table
        $sql = "DELETE FROM bookings WHERE booking_id = $booking_id";
        $conn->query($sql);

        echo "<script>alert('Booking declined!');</script>";
    }
}

// Fetch Existing Bookings for Display
$sql = "SELECT * FROM bookings";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Display the existing bookings in the HTML table
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td class='px-4 py-3'>" . $row["booking_id"] . "</td>";
        echo "<td class='px-4 py-3'>" . $row["user_id"] . "</td>";
        echo "<td class='px-4 py-3'>" . $row["details"] . "</td>";
        echo "<td class='px-4 py-3'>" . $row["booking_date"] . "</td>";
        echo "<td class='px-4 py-3'>" . $row["status"] . "</td>";
        echo "<td class='px-4 py-3'>";
        echo "<form method='POST' action='" . $_SERVER['PHP_SELF'] . "'>";
        echo "<input type='hidden' name='booking_id' value='" . $row["booking_id"] . "'>";
        echo "<button type='submit' name='approve' class='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded'>Approve</button>";
        echo "<button type='submit' name='decline' class='bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded ml-2'>Decline</button>";
        echo "</form>";
        echo "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6' class='px-4 py-3 text-center'>No bookings found.</td></tr>";
}

$conn->close();
?>