<?php
// PHP functions to fetch data from the database
function getTotalUsers() {
    // Replace with your database connection details
    $conn = new mysqli('0.0.0.0', 'root', 'root', 'Construction');
    $result = $conn->query("SELECT COUNT(*) AS total FROM users");
    $data = $result->fetch_assoc();
    return $data['total'];
}

function getActiveUsers() {
    // Replace with your database connection details
    $conn = new mysqli('0.0.0.0', 'root', 'root', 'Construction');
    $result = $conn->query("SELECT COUNT(*) AS total FROM users WHERE is_active = 1");
    $data = $result->fetch_assoc();
    return $data['total'];
}

function getPendingBookings() {
    // Replace with your database connection details
    $conn = new mysqli('0.0.0.0', 'root', 'root', 'Construction');
    $result = $conn->query("SELECT COUNT(*) AS total FROM bookings WHERE status = 'Pending'");
    $data = $result->fetch_assoc();
    return $data['total'];
}

function getPendingBookingsTable() {
    // Replace with your database connection details
    $conn = new mysqli('0.0.0.0', 'root', 'root', 'Construction');
    $result = $conn->query("SELECT bookings.booking_id, users.username, bookings.details, bookings.booking_date FROM bookings JOIN users ON bookings.user_id = users.user_id WHERE bookings.status = 'Pending'");
    $rows = '';
    while ($row = $result->fetch_assoc()) {
        $rows .= '<tr class="shadow-md">
                    <td class="px-4 py-2">' . $row['booking_id'] . '</td>
                    <td class="px-4 py-2">' . $row['username'] . '</td>
                    <td class="px-4 py-2">' . $row['details'] . '</td>
                    <td class="px-4 py-2">' . $row['booking_date'] . '</td>
                    <td class="px-4 py-1">
                        <button class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">Details</button>
                    </td>
                  </tr>';
    }
    return $rows;
}


function getRecentActivity() {
    // Replace with your database connection details
    $conn = new mysqli('0.0.0.0', 'root', 'root', 'Construction');
    $result = $conn->query("SELECT users.username, activity_log.action FROM activity_log JOIN users ON activity_log.user_id = users.user_id ORDER BY activity_log.created_at DESC LIMIT 10");
    $activity = '';
    while ($row = $result->fetch_assoc()) {
        $activity .= '<li class="border-b py-2"> <strong>'  . /* $row['username']*/  '02:22'. '</strong> ' . $row['action'] . '.</li>';
    }
    return $activity;
}
?>