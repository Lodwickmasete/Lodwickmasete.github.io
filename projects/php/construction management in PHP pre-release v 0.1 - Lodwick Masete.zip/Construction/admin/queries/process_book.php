<?php
 include '../db_conn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];
    $details = $_POST['details'];
    $booking_date = $_POST['booking_date'];

    $sql = "INSERT INTO bookings (user_id, details, booking_date) VALUES ($user_id, '$details', '$booking_date')";

    if ($conn->query($sql) === TRUE) {
        $log_sql = "INSERT INTO activity_log (user_id, action) VALUES ($user_id, 'Booking created')";
        $conn->query($log_sql);
        echo "Booking created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>