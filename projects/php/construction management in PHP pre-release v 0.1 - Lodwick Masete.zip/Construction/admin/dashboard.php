<?php include 'db_conn.php'; ?>
<?php include 'dash.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>


<body class="bg-gray-100 text-gray-800 flex ">

    <!-- Sidebar -->
    <nav class="sidebar w-1/4 p-6 bg-blue-900 text-white">
        <h1 class="text-white text-2xl font-bold mb-6">Admin Panel</h1>
        <a href="#" class="block py-2 font-semibold">Dashboard</a>
        <a href="#" class="block py-2 " onclick="LoadPage('book.php')">Users</a>
        <a href="#" class="block py-2">Settings</a>
        <a href="#" class="block py-2">Reports</a>
        <a href="#" class="block py-2">Logout</a>
    </nav>

    <!-- Main Content -->

    <main class="content w-3/4 bg-white shadow-md rounded-lg p-6" id="Pages">
        <h2 class="text-2xl font-bold mb-4">Dashboard</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <div class="bg-blue-500 text-white p-4 rounded-lg shadow">
                <h3 class="text-lg font-semibold">Total Users</h3>
                <p class="text-2xl mt-2"><?php echo getTotalUsers(); ?></p>
            </div>
            <div class="bg-green-500 text-white p-4 rounded-lg shadow">
                <h3 class="text-lg font-semibold">Active Users</h3>
                <p class="text-2xl mt-2"><?php echo getActiveUsers(); ?></p>
            </div>
            <div class="bg-yellow-500 text-white p-4 rounded-lg shadow">
                <h3 class="text-lg font-semibold">Pending Bookings 
                <p class="text-2xl mt-2"><?php echo getPendingBookings(); ?></p>
            </div>
            <div class="bg-red-500 text-white p-4 rounded-lg shadow">
                <h3 class="text-lg font-semibold">Server Uptime</h3>
                <p class="text-2xl mt-2">99.99%</p>
            </div>
        </div>

<div class="bg-white p-6 rounded-lg shadow-md">
           <h3 class="text-xl font-bold mb-4">Pending Bookings</h3>
           <div class="booking-table overflow-x-auto">
               <table class="w-full table-auto">
                   <thead>
                       <tr>
                           <th class="px-4 py-2">Booking ID</th>
                           <th class="px-4 py-2">User</th>
                           <th class="px-4 py-2">Details</th>
                           <th class="px-4 py-2">Date</th>
                           <th class="px-4 py-2">Actions</th>
                       </tr>
                   </thead>
                   <tbody>
                       <?php echo getPendingBookingsTable(); ?>
                   </tbody>
               </table>
           </div>
       </div>

        <div class="bg-white p-6 rounded-lg shadow-md mt-6">
            <h3 class="text-xl font-bold mb-4">Recent Activity</h3>
            <ul>
                <?php echo getRecentActivity(); ?>
            </ul>
        </div>
    </main>

</body>
</html>
<script>
function LoadPage(pagepath) {
  // Show loading text
  const loadingText = document.createElement('div');
  loadingText.textContent = 'Loading...';
  loadingText.style.textAlign = 'center';
  loadingText.style.fontSize = '24px';
  loadingText.style.marginTop = '100px';
  document.getElementById('Pages').appendChild(loadingText);

  // Create a FormData object to hold the data
  const formData = new FormData();
  formData.append('ref', '1');
  formData.append('role', 'admin');

  // Fetch the page using POST request
  fetch(pagepath, {
    method: 'POST',
    body: formData
  })
  .then(response => {
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    return response.text(); // Assuming the server returns plain text HTML
  })
  .then(html => {
    // Remove loading text
    loadingText.remove();

    // Update the Pages section with the fetched HTML
    document.getElementById('Pages').innerHTML = html;
  })
  .catch(error => {
    // Handle errors (e.g., display an error message)
    console.error('Error loading page:', error);
    loadingText.textContent = 'Error loading page';
  })
  .finally(() => {
    // Optional: Remove the loading text after a set time (2 seconds)
    setTimeout(() => {
      loadingText.remove();
    }, 2000);
  });
}
</script>