<?php
 include '../admin/db_conn.php';

 if ($_SERVER["REQUEST_METHOD"] == "POST") {
     $username = $_POST['username'];
     $email = $_POST['email'];
     $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

     $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";

     if ($conn->query($sql) === TRUE) {
         $user_id = $conn->insert_id;
         $log_sql = "INSERT INTO activity_log (user_id, action) VALUES ($user_id, 'New User registered')";
         $conn->query($log_sql);
         echo "New record created successfully";
         exit;
     } else {
         echo "Error: " . $sql . "<br>" . $conn->error;

     }

     $conn->close();
 }
 ?>