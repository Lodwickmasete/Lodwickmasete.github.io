<?php
// Assuming you have a directory named "files"

// Get the path from the request
$path = $_GET['path']; // Use $_GET as DELETE requests don't have a request body by default

// Sanitize path (important for security!)
$path = realpath(__DIR__ . '/files/' . $path);

// Check if the path exists and is a file
if (is_file($path)) {
    if (unlink($path)) {
        echo json_encode(['success' => true]); // Indicate success
    } else {
        echo json_encode(['success' => false, 'error' => 'Error deleting file']); // Indicate failure
    }
} else {
    echo json_encode(['success' => false, 'error' => 'File not found']); // Indicate file not found
}
?>