<?php
// Assuming you have a directory named "files"
$path = $_GET['path'];

// Sanitize path (important for security!)
$path = realpath(__DIR__ . '/files/' . $path);

// Check if the path exists and is a directory
if (is_dir($path)) {
    $files = scandir($path);

    // Generate breadcrumb
    $breadcrumb = "<span onclick=\"LoadPath('')\">Home</span>";
    $pathParts = explode('/', str_replace(realpath(__DIR__ . '/files'), '', $path));
    $accumPath = '';
    foreach ($pathParts as $part) {
        if (!empty($part)) {
            $accumPath .= '/' . $part;
            $breadcrumb .= " / <span onclick=\"LoadPath('$accumPath')\">$part</span>";
        }
    }

    echo "<div class='breadcrumb'>$breadcrumb</div>";

    // Add a "parent directory" item to navigate to the previous path
    $parentPath = dirname($path);
    if ($parentPath === realpath(__DIR__ . '/files')) {  // Only show if not in the root directory
        $relativeParentPath = str_replace(realpath(__DIR__ . '/files'), '', $parentPath);
        echo "<div class='file-item folder' onclick=\"LoadPath('$relativeParentPath')\">";
        echo "<div class='dots'>⋮</div>";
        echo "<div class='icon'>📁</div>";
        echo "<div class='name'>...</div>";
        echo "<div class='size'>--</div>";
        echo "</div>";
    }

    // Define file type icon classes with emojis
    $fileIcons = [
        'txt' => ['class' => 'text-icon', 'emoji' => '📝'],
        'pdf' => ['class' => 'pdf-icon', 'emoji' => '📄'],
        'doc' => ['class' => 'doc-icon', 'emoji' => '📄'],
        'docx' => ['class' => 'docx-icon', 'emoji' => '📄'],
        'xls' => ['class' => 'xls-icon', 'emoji' => '📊'],
        'xlsx' => ['class' => 'xlsx-icon', 'emoji' => '📊'],
        'png' => ['class' => 'image-icon', 'emoji' => '🖼️'],
        'jpg' => ['class' => 'image-icon', 'emoji' => '🖼️'],
        'jpeg' => ['class' => 'image-icon', 'emoji' => '🖼️'],
        'gif' => ['class' => 'image-icon', 'emoji' => '🖼️'],
        'zip' => ['class' => 'zip-icon', 'emoji' => '🗜️'],
        'rar' => ['class' => 'rar-icon', 'emoji' => '🗜️'],
        'mp3' => ['class' => 'audio-icon', 'emoji' => '🎵'],
        'wav' => ['class' => 'audio-icon', 'emoji' => '🎵'],
        'mp4' => ['class' => 'video-icon', 'emoji' => '🎥'],
        'avi' => ['class' => 'video-icon', 'emoji' => '🎥'],
        // Add more file types as needed
    ];

    // Output HTML for file items
    $file_id = 1;
    foreach ($files as $file) {
        if ($file != '.' && $file != '..') {
            $file_path = $path . '/' . $file;
            $is_folder = is_dir($file_path);

            // Determine the icon class and emoji based on file type
            $extension = pathinfo($file, PATHINFO_EXTENSION);
            $iconClass = $is_folder ? '📁' : (isset($fileIcons[$extension]) ? $fileIcons[$extension]['emoji'] . ' ' : '📄');
            $fileType = $is_folder ? 'folder' : 'file';

            // Determine the correct function to call based on whether it's a file or folder
            $relativeFilePath = str_replace(realpath(__DIR__ . '/files'), '', $file_path);
            $loadFunction = $is_folder ? "LoadPath('$relativeFilePath')" : "LoadFile('$relativeFilePath')";

            echo "<div class='file-item $fileType' data-file-id='$file_id' onclick=\"$loadFunction\">";
            echo "<div class='item-holder'>";
            echo "<div class='dots'>⋮</div>";
            echo "<div class='icon'>$iconClass</div>";
            echo "<div class='name'>$file</div>";
            echo "<div class='size'>" . ($is_folder ? '--' : filesize($file_path) . ' bytes') . "</div>";
            echo '<div class="file-options">
                 <button class="download">Download</button>';
            echo '<button class="delete" onclick="deleteFile(' . $relativeFilePath .')">Delete</button>
            </div>';
            
            echo "</div>";
            echo "</div>";

            $file_id++;
        }
    }
} else {
    echo 'Invalid path';
}
?>