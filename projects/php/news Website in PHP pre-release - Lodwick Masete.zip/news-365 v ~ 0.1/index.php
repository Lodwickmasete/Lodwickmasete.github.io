<?php include 'db/db_conn.php'; ?>
<?php include 'header.php'; ?>
<body>

<!-- Loading Bar Container -->
<div id="loading-bar-container">
    <div id="loading-bar"></div>
</div>


<!-- Navigation -->
<?php include './pages/nav.php'; ?>
<?php include 'category.php'; ?>
<div id="main-content" class="fade-in">

</div>
<div id="current-see-more">

</div>
</body>
</html>



<script>
function showFullContent(seeMoreLink) {
    const article = seeMoreLink.closest('article');
    const fullContentDiv = article.querySelector('.full-content');
    const currentSeeMoreDiv = document.getElementById('current-see-more');

    // Toggle content within the article
    fullContentDiv.style.display = fullContentDiv.style.display === 'none' ? 'block' : 'none';

    // Update current-see-more div
    currentSeeMoreDiv.innerHTML = fullContentDiv.innerHTML; 
    currentSeeMoreDiv.style.display = 'block';

}

</script>


<script>

loadPage('home');

function loadPage(pageName) {
    document.getElementById('loading-bar').style.width = '0%'; // Reset progress bar
    document.getElementById('loading-bar').style.display = 'block'; // Show progress bar
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById('main-content').classList.remove('fade-in');
            document.getElementById('main-content').classList.add('fade-out');
            setTimeout(function() {

                document.getElementById('main-content').innerHTML = this.responseText;
                document.getElementById('main-content').classList.remove('fade-out');
                document.getElementById('main-content').classList.add('fade-in');
                document.getElementById('loading-bar').style.width = '100%'; // Update progress bar width to 100%
                setTimeout(function() {
                    document.getElementById('loading-bar').style.display = 'none'; // Hide progress bar
                }, 300); // Delay to allow progress bar animation to complete
            }.bind(this), 500); // Wait for the fade-out transition to complete
        }
    };
    xhttp.open("GET",'./pages/'+ pageName + '.php', true);
    xhttp.send();

    // Remove active class from all links
    var links = document.querySelectorAll('ul li a');
    links.forEach(function(link) {
        link.classList.remove('active');
    });

    // Add active class to the clicked link
    document.getElementById(pageName).classList.add('active');
    

}

</script>