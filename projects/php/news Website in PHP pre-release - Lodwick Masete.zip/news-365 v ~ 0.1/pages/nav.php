<?php
// Assuming you have a database connection established

// Fetch data from the navigation_tabs table
$query = "SELECT tab_name, value FROM navigation_tabs";
$result = mysqli_query($conn, $query);

// Check if the query was successful
if (!$result) {
    // Handle the error, for example:
    die("Error: " . mysqli_error($conn));
}

// Initialize an empty array to store tabs that are set to 'on'
$active_tabs = array();

// Loop through the result set
while ($row = mysqli_fetch_assoc($result)) {
    if ($row['value'] == 'on') {
        // If the value is 'on', add the tab name to the array
        $active_tabs[] = $row['tab_name'];
    }
}

// Output the HTML for the navigation list
echo '<ul class="nav">';
foreach ($active_tabs as $tab) {
    // Output each active tab as a list item
    echo '<li><a href="#" id="' . $tab . '" onclick="loadPage(\'' . $tab . '\')">' . ucfirst($tab) . '</a></li>';
}
// Add the 'plus' tab
echo '<li><a href="#" id="category" onclick="loadPage(\'category\')">+</a></li>';
echo '</ul>';
?>