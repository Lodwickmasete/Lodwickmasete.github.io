<style>
       .actions {
           display: flex;
           justify-content: space-between; 
           align-items: flex-start; 
           margin-top: -20px; 
           position: relative; 
           top: 0; 
           left: 0; 
       }

       .options {
           font-size: 14px; 
           font-weight: bold; 
       }

       .likes, .views, .options {
           font-size: 14px; 
       }

       .text-image-container {
           padding: 15px 30px;
           display: flex;
           align-items: center; 
           margin-bottom: 20px; 
       }

       .text-image-container img {
           width: 300px; 
           height: auto;
           margin-right: 20px; 
           border-radius: 10px; 
           box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
           cursor: pointer; /* Add cursor pointer for image */
       }

       .text-content {
           flex: 1; 
       }

       .text-content h2 {
           margin-bottom: 10px; 
       }

       .text-content p {
           line-height: 1.5; 
       }

       #downloadBtn {
           display: none;
       }
   </style>
</head>

   <div class="text-image-container">
       <img src="1.jpg" alt="Example Image" id="mainImage">
       <div class="text-content">
           <h2>This is the Text Content</h2>
           <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl a luctus laoreet, nunc lectus efficitur dolor, vitae facilisis leo diam in nisl.</p>
           <span class="likes">❤️ 150</span>
           <span class="views">👀 200</span>
       </div>
       <div class="actions">
           <span class="options">⋮</span>
       </div>
   </div>

<div class="text-image-container">
   <img src="3.jpg" alt="Example Image" id="mainImage">
   <div class="text-content">
       <h2>This is the Text Content</h2>
       <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl a luctus laoreet, nunc lectus efficitur dolor, vitae facilisis leo diam in nisl.</p>
       <span class="likes">❤️ 150</span>
       <span class="views">👀 200</span>
   </div>
   <div class="actions">
       <span class="options">⋮</span>
   </div>
</div>

   <button id="downloadBtn">Download Image</button>

   <script>
       const mainImage = document.getElementById('mainImage');
       const downloadBtn = document.getElementById('downloadBtn');

       // Zoom image when clicked
       mainImage.addEventListener('click', () => {
           mainImage.style.transform = 'scale(1.2)';
           downloadBtn.style.display = 'block';
       });

       // Unzoom image when clicked outside the zoomed image
       document.addEventListener('click', (event) => {
           if (event.target !== mainImage) {
               mainImage.style.transform = 'scale(1)';
               downloadBtn.style.display = 'none';
           }
       });

       // Download image when download button is clicked
       downloadBtn.addEventListener('click', () => {
           const imageSrc = mainImage.src;
           const a = document.createElement('a');
           a.href = imageSrc;
           a.download = 'image.jpg';
           a.click();
       });

       // Copy text when options button is clicked
       const optionsBtn = document.querySelector('.options');
       optionsBtn.addEventListener('click', () => {
           const textContent = document.querySelector('.text-content').innerText;
           navigator.clipboard.writeText(textContent)
               .then(() => alert('Text copied successfully'))
               .catch((error) => console.error('Error copying text:', error));
       });
   </script>

</html>