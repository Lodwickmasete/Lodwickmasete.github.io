 <style>
        .actions {
            display: flex;
            justify-content: space-between; 
            align-items: flex-start; 
            margin-top: -180px; 
            position: relative; 
            top: 0; 
            left: 0; 
        }

        .options {
            font-size: 14px; 
            font-weight: bold; 
        }

        .likes, .views, .options {
            font-size: 14px; 
        }

        .text-image-container {
            padding: 15px 30px;
            display: flex;
            align-items: center; 
            margin-bottom: 20px; 
            
        }

        .text-image-container img {
        
            width: 300px; 
            height: auto;
            margin-right: 20px; 
            border-radius: 10px; 
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
            cursor: pointer; /* Add cursor pointer for image */
        }

        .text-content {
            flex: 1; 
            
        }

        .text-content h2 {
            margin-bottom: 10px; 
            
        }

        .text-content p {
            line-height: 1.5; 
        }

        #downloadBtn {
            display: none;
            
        }
    </style>
</head>

    <div class="text-image-container">
        <img src="1.jpg" alt="Example Image" id="">
        <div class="text-content">
            <h2>This is the title</h2>
            <p>
this is headline txt          
            </p>
            <span class="likes">❤️ 150</span>
            <span class="views">👀 200</span>
        </div>
        <div class="actions">
            <span class="options">⋮</span>
        </div>
    </div>

<div class="text-image-container">
    <img src="2.jpg" alt="Example Image" id="">
    <div class="text-content">
        <h2>This is the title</h2>
        <p>
this is headline txt
        </p>
        <span class="category name">headlines</span>
        <span class="follow_state">Not following</span>
    </div>
    <div class="actions">
        <span class="options">⋮</span>
    </div>
</div>