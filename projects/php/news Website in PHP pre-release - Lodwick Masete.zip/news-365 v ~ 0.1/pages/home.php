
<?php
include '../db/db_conn.php'; 

// Categories
$categories = array('headlines', 'breaking', 'recent' , 'madeira');

// Fetch news data for each category (latest article)
$newsData = array();
foreach ($categories as $category) {
    $sql = "SELECT * FROM news WHERE category='$category' ORDER BY id DESC LIMIT 1";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $newsData[$category] = $result->fetch_assoc();
    }
}

// Get current user ID 
$userID = 1;

// Fetch user's category preferences
$sql = "SELECT follows_headlines, follows_breaking, follows_recent FROM users WHERE id = $userID";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $userPrefs = $result->fetch_assoc();

    // Display articles based on user preferences
    echo '<section>';
    foreach ($categories as $category) {
        $followsCategory = $userPrefs['follows_' . $category] === 'yes';
        if ($followsCategory && isset($newsData[$category])) {
            $row = $newsData[$category];
            echo '<article id="' . $row['id'] . '" data-category="' . $category . '">';
            echo '<h2>' . ucfirst($category) . '</h2>';
            echo '<p class="short-content">' . substr($row['content'], 0, 25) . '... ';
            echo '<b href="#" class="see-more" onclick="showFullContent(this)">See more</b></p>';
            echo '<div class="full-content" style="display:none;">' . $row['content'] . '</div>';
            echo '</article>';
        }
        
        
    }
    echo '</section>';
    echo '<div id="current-see-more"></div>'; // Div for full content



foreach ($categories as $category) {
    $followsCategory = $userPrefs['follows_' . $category] === 'yes';
    if ($followsCategory) {
        $sql = "SELECT * FROM news WHERE category='$category' ORDER BY id DESC";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="text-image-container">';
                echo '<img src="../2.jpg" alt="Example Image" id="">';
                echo '<div class="text-content">';
                echo '<h2>' . $row['title'] . '</h2>';
                echo '<p>' . $row['content'] . '</p>';
                echo '<span class="like">' . ucfirst($category) . '</span>';
                echo '<span class="views">Following</span>'; // Assuming the user is following this category
                echo '</div>';
                echo '<div class="actions">';
                echo '<span class="options">⋮</span>';
                echo '</div>';
                echo '</div>';
            }
        }
    }
}

} else {
    echo 'User not found';
}

$conn->close();
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News Website</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;

 
        }

        header {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px 0;
        }

        nav {
            background-color: #444;
            color: white;
            text-align: center;
            padding: 10px 0;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin: 0 10px;
        }

        section {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            padding: 20px;
        }

        article {
            background-color: white;
            padding: 10px;
            border-radius: 5px;
        }

        h2 {
            color: #333;
        }

        p {
            color: #666;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px 0;
        }
        
        .short-content {
        margin-bottom: 10px;
        }
        
        .see-more {
        color: blue;
        cursor: pointer;
        }
        
        .full-content {
        display: none;
        margin-top: 10px;
        }
    </style>
    

    
    
    
</head>
<body>



<?php
include '../script.php';
?>