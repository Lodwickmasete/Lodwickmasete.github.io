<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>News Page Website</title>
<link rel="stylesheet" href="./css/checkbox.css">
<link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./awe/css/all.min.css">
<style>
       .actions {
           display: flex;
           justify-content: space-between; 
           align-items: flex-start; 
           margin-top: -180px; 
           position: relative; 
           top: 0; 
           left: 0; 
       }

       .options {
           font-size: 14px; 
           font-weight: bold; 
       }

       .likes, .views, .options {
           font-size: 14px; 
       }

       .text-image-container {
           padding: 15px 30px;
           display: flex;
           align-items: center; 
           margin-bottom: 20px; 
           
       }

       .text-image-container img {
       
           width: 300px; 
           height: auto;
           margin-right: 20px; 
           border-radius: 10px; 
           box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
           cursor: pointer; /* Add cursor pointer for image */
       }

       .text-content {
           flex: 1; 
           
       }

       .text-content h2 {
           margin-bottom: 10px; 
           
       }

       .text-content p {
           line-height: 1.5; 
       }

       #downloadBtn {
           display: none;
           
       }
   </style>
</head>