<?php
// Database connection
$servername = "127.0.0.1";
$username = "root";
$password = "root";
$dbname = "news";


$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category = $_POST['category'];
    $follows = $_POST['follows'];
    $userID = 1; // Replace with your actual user ID retrieval mechanism 

    // Update user's preference in the database
    $sql = "UPDATE users SET follows_".$category." = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $follows, $userID); 
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "home";
    } else {
        echo "error";
    }
    $stmt->close();
}

$conn->close();
?>