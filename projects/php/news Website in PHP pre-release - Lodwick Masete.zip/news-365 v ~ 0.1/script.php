<script>
function showFullContent(seeMoreLink) {
    const article = seeMoreLink.closest('article');
    const fullContentDiv = article.querySelector('.full-content');
    const currentSeeMoreDiv = document.getElementById('current-see-more');

    // Toggle content within the article
    fullContentDiv.style.display = fullContentDiv.style.display === 'none' ? 'block' : 'none';

    // Update current-see-more div
    currentSeeMoreDiv.innerHTML = fullContentDiv.innerHTML; 
    currentSeeMoreDiv.style.display = 'block';
    loadPage('home');
}

</script>