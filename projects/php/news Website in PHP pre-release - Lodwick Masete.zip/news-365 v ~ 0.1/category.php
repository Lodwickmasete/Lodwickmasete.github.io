<?php include 'db/db_conn.php'; ?>

<?php
        
        // Categories
        $categories = array('headlines', 'breaking', 'recent');
        
        // Fetch news data for each category (latest article)
        $newsData = array();
        foreach ($categories as $category) {
        $sql = "SELECT * FROM news WHERE category='$category' ORDER BY id DESC LIMIT 1";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        $newsData[$category] = $result->fetch_assoc();
        }
        }
        
        // Get current user ID (replace with your actual user identification method)
        $userID = 1; //assume user 1 for now , Replace with actual user ID
        
// Fetch user's category preferences
$sql = "SELECT follows_headlines, follows_breaking, follows_recent FROM users WHERE id = $userID";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $userPrefs = $result->fetch_assoc();
} else {
    // User not found in database, create a new entry with default preferences
    $sql = "INSERT INTO users (id, follows_headlines, follows_breaking, follows_recent) VALUES ($userID, 'no', 'no', 'no')";
    $conn->query($sql);
    $userPrefs = array('follows_headlines' => 'no', 'follows_breaking' => 'no', 'follows_recent' => 'no');
}
?>
    </ul>

<ul class="ks-cboxtags">
    <?php 
    foreach ($categories as $category): ?>
        <li>
            <input type="checkbox" id="<?= $category ?>-check" value="<?= $category ?>-check"
                   <?php if (isset($userPrefs['follows_' . $category]) && $userPrefs['follows_' . $category] === 'yes'): ?>
                       checked
                   <?php endif; ?>
                   onchange="updatePreference(this)">
            <label for="<?= $category ?>-check"><?= ucfirst($category) ?></label>
        </li>
    <?php endforeach; ?>
</ul>


<script>
function updatePreference(checkbox) {
    var category = checkbox.id.replace('-check', '');
    var isChecked = checkbox.checked;

    var xhr = new XMLHttpRequest();
    xhr.open("POST", "./config/update_preferences.php");
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onload = function() {
        if (xhr.status === 200) {

            loadPage(xhr.responseText);
        } else {
            console.error('Error updating preferences.');
        }
    };
    xhr.send("category=" + category + "&follows=" + (isChecked ? 'yes' : 'no'));

}
</script>