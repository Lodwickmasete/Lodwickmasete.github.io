<?php
header('Content-Type: application/json');

// File path
$jsonFile = 'data.json';

// Load JSON data from file
if (file_exists($jsonFile)) {
    $data = json_decode(file_get_contents($jsonFile), true);
    echo json_encode(['current-multiply' => $data['current-multiply']]);
} else {
    echo json_encode(['current-multiply' => null]);
}
?>