<?php
header('Content-Type: application/json');

// Read the data.json file
$data = json_decode(file_get_contents('data.json'), true);


       if (isset($_POST['amount']) && ($_POST['user_id'])) {
// Get the bet amount from the POST request
$amount = $_POST['amount'];
$user_id = $_POST['user_id'];

// Read the user id file
$userFile = $user_id .'.json';
if (!file_exists($userFile)) {
    // Initialize user data if the file doesn't exist
    $userData = [
        "money" => 10,
        "bet-amount" => 0,
    ];
    file_put_contents($userFile, json_encode($userData));
} else {
    $userData = json_decode(file_get_contents($userFile), true);
}

$response = [];

if ($data['current-multiply'] == "null") {
    // Deduct bet amount from user's money and update bet amount
    if ($userData['money'] >= $amount) {
        $userData['money'] -= $amount;
        $userData['bet-amount'] = $amount;
        $response = ["success" => true, "message" => "Bet accepted"];
       file_put_contents($userFile, json_encode($userData));
    } else {
        $response = ["success" => false, "message" => "Insufficient funds"];
    }
} else {
    // Decline bet since there's an ongoing round
    $userData['bet-amount'] = 0;
    $response = ["success" => false, "message" => "Bet declined. There's an ongoing round."];
}




// Send response
echo $userFile;
}
else {
echo 'what you are trying to do is not allowed.your account may get blocked';
}
?>