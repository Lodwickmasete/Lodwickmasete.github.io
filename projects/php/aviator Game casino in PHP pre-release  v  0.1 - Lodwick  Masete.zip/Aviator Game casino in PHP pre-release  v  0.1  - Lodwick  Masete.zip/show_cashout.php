<?php
header('Content-Type: application/json');

if (!isset($_GET['user_id'])) {
    echo json_encode(['cashout' => null]);
    exit;
}

$user_id = $_GET['user_id'];
$jsonFile = 'data.json';
$userFile = $user_id . '.json';

if (file_exists($jsonFile) && file_exists($userFile)) {
    $data = json_decode(file_get_contents($jsonFile), true);
    $bet_amount = json_decode(file_get_contents($userFile), true);

    if (isset($data['current-multiply']) && is_numeric($data['current-multiply'])) {
        $cashoutAmount = $data['current-multiply'] * $bet_amount['bet-amount'];
        echo json_encode(['cashout' => $cashoutAmount]);
    } else {
        echo json_encode(['cashout' => null]);
    }
} else {
    echo json_encode(['cashout' => null]);
}
?>