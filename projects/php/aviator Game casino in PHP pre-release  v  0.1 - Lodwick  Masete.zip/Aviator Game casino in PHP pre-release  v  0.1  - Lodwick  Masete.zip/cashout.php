<?php
header('Content-Type: application/json');

// Get the POST data
$user_id = $_POST['user_id'];

// Check if user_id is provided
if (!isset($user_id)) {
    echo json_encode(["success" => false, "message" => "User ID not provided"]);
    exit;
}

// Get the multiplier from the data.json file
$data = json_decode(file_get_contents('data.json'), true);
$multiplier = $data['current-multiply'] ?? null;

// Read the user file
$userFile = "{$user_id}.json";
if (!file_exists($userFile)) {
    echo json_encode(["success" => false, "message" => "User not found"]);
    exit;
}

$userData = json_decode(file_get_contents($userFile), true);

$response = [];

if ($multiplier !== null && $userData['bet-amount'] > 0) {
    // Calculate cashout value
    $cashoutValue = $userData['bet-amount'] * $multiplier;
    $userData['money'] += $cashoutValue;
    $userData['bet-amount'] = 0;
    $response = ["success" => true, "message" => "Cashed out $cashoutValue"];
} else {
    $response = ["success" => false, "message" => "Multiplier is invalid or You have no active bet."];
}

// Save updated user data
file_put_contents($userFile, json_encode($userData));

// Send response
echo json_encode($response);
?>