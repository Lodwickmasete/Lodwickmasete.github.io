<?php
$ran_id = rand(1,10);

echo $ran_id;
?>