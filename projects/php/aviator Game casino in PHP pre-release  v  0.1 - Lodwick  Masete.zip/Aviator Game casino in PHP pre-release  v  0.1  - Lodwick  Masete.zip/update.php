<?php
session_start();
header('Content-Type: application/json');

// Read the data.json file
$data = json_decode(file_get_contents('data.json'), true);

// Read the rounds.json file
$roundsFile = 'rounds.json';
if (file_exists($roundsFile)) {
    $rounds = json_decode(file_get_contents($roundsFile), true);
} else {
    $rounds = [];
}



// Check if there's a number in the session
if (!isset($_SESSION['random'])) {
$limiter = random_int(1, 5);
$limiter_2 = random_int(1, 10);
$limiter_3 = random_int(1, 20);
$limiter_4 = random_int(1, 40);
$hot_limiter = random_int(20, 199);


$special = [$limiter_4,$limiter,'1',$limiter_3,$limiter,$limiter_2,'1','1.01',$hot_limiter,'1','1.01',$limiter];

// Generate a random number
$random = $special[array_rand($special)];

$_SESSION['random'] = $random;
    }


// Define the ranges and corresponding increment values
$ranges = [
    ['min' => 5.00, 'max' => 10.00, 'increment' => 0.03],
    ['min' => 10.01, 'max' => 30.00, 'increment' => 0.3],
    ['min' => 30.01, 'max' => 60.00, 'increment' => 0.50],
    ['min' => 60.01, 'max' => null, 'increment' => 1.38] // No upper bound for the last range
];

// Check if the multiplier is set and update it
if (isset($data['current-multiply'])) {
    if ($data['current-multiply'] < $_SESSION['random']) {
        $data['current-multiply'] += 0.01;
    } else {
    
       if (isset($_SESSION['random'])) {
         unset($_SESSION['random']);
         }
        // Log the reached multiplier into rounds.json before setting it to "-"
        $lastMultiplier = $data['current-multiply'];
        $data['current-multiply'] = "null";

        // Determine the next roundId
        $nextRoundId = count($rounds) > 0 ? end($rounds)['roundId'] + 1 : 1;

        // Add the new round to the rounds.json array
        if (count($rounds) >= 5) {
            array_shift($rounds); // Remove the oldest entry if we have 10 entries
        }
        $rounds[] = ['multiplier' => $lastMultiplier, 'roundId' => $nextRoundId];

        file_put_contents($roundsFile, json_encode($rounds));

        // Reset current-multiply after 5 seconds
        file_put_contents('data.json', json_encode($data));
        sleep(10); // Wait for 5 seconds
        $data['current-multiply'] = 1;
    }

    // Apply the additional increment based on the defined ranges
    foreach ($ranges as $range) {
        if ($data['current-multiply'] >= $range['min'] && 
            ($range['max'] === null || $data['current-multiply'] <= $range['max'])) {
            $data['current-multiply'] += $range['increment'];
            break; // Stop checking further ranges once matched
        }
    }

} else {
    $data['current-multiply'] = 1;
}

// Write the updated value back to the JSON file
file_put_contents('data.json', json_encode($data));

// Output the current value
echo json_encode($data);

?>