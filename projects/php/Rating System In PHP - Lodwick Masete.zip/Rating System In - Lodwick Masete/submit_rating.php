 <?php
$rating = $_POST['rating'];
$comment = $_POST['comment'];

$file = 'comments.html';
$current = file_get_contents($file);
$current .= "<div class='comment'><p><strong>Rating:</strong> $rating stars</p><p><strong>Comment:</strong> $comment</p></div>";
file_put_contents($file, $current);
 include 'comments.html'; 
?>