
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rating System</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Rate en act</h1>
    <form action="submit_rating.php" method="POST">
        <label for="rating">Rate Us (1-5):</label>
        <input type="number" name="rating" id="rating" min="1" max="5" required>
        <br>
        <label for="comment">Additional Comments:</label>
        <textarea name="comment" id="comment" cols="30" rows="5"></textarea>
        <br>
        <button type="submit">Submit Rating</button>
    </form>
</body>
</html>
