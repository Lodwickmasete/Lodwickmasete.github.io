<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Text Editor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        #editor {
            width: 100%;
            height: 300px;
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 20px;
            resize: vertical;
        }

        .button-group {
            text-align: center;
        }

        button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0056b3;
        }

        #fileList {
            max-height: 200px;
            overflow-y: auto;
            border: 1px solid #ccc;
            padding: 10px;
            background-color: #f9f9f9;
            border-radius: 5px;
        }

        #fileList ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        #fileList li {
            padding: 5px;
            border-bottom: 1px solid #ddd;
        }

        #fileList li:last-child {
            border-bottom: none;
        }

        #fileList li a {
            text-decoration: none;
            color: #333;
            transition: color 0.3s ease;
        }

        #fileList li a:hover {
            color: #007bff;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Web Text Editor</h1>
        <textarea id="editor" placeholder="Start typing here..."></textarea>
        <div class="button-group">
            <button onclick="saveFile()">Save File</button>
            <button onclick="createFolder()">Create Folder</button>
        </div>
        <div id="fileList">
            <h2>Files and Folders</h2>
            <ul>
                <?php
                // PHP code to list files and folders
                $files = glob('192.168.8.1/*');
                foreach ($files as $file) {
                    if (is_file($file)) {
                        echo '<li><a href="' . $file . '">' . basename($file) . '</a></li>';
                    } elseif (is_dir($file)) {
                        echo '<li><a href="#">' . basename($file) . '</a></li>';
                    }
                }
                ?>
            </ul>
        </div>
    </div>


    <script>
        // Function to save content to a file
        function saveFile() {
            var filename = prompt("Enter a filename:");
            if (filename) {
                var content = document.getElementById("editor").value;
                var formData = new FormData();
                formData.append("action", "save");
                formData.append("filename", filename);
                formData.append("content", content);

                fetch("backend.php", {
                    method: "POST",
                    body: formData
                })
                .then(response => response.text())
                .then(data => {
                    alert(data);
                    // Update file list after saving
                    updateFileList();
                })
                .catch(error => console.error("Error:", error));
            }
        }

        // Function to create a new folder
        function createFolder() {
            var foldername = prompt("Enter a folder name:");
            if (foldername) {
                var formData = new FormData();
                formData.append("action", "create_folder");
                formData.append("foldername", foldername);

                fetch("backend.php", {
                    method: "POST",
                    body: formData
                })
                .then(response => response.text())
                .then(data => {
                    alert(data);
                    // Update file list after creating folder
                    updateFileList();
                })
                .catch(error => console.error("Error:", error));
            }
        }

        // Function to update file list
        function updateFileList() {
            fetch("backend.php")
                .then(response => response.text())
                .then(data => {
                    document.getElementById("fileList").innerHTML = data;
                })
                .catch(error => console.error("Error:", error));
        }

        // Initial file list update
        updateFileList();
    </script>
</body>
</html>