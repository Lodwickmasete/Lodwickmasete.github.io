<?php
// Function to save content to a file with input validation
function saveFile($filename, $content) {
    // Validate file name to prevent directory traversal attacks
    $filename = basename($filename);
    $filename = preg_replace('/[^A-Za-z0-9_.-]/', '', $filename); // Remove any special characters
    $filename = 'uploads/' . $filename; // Assume uploads directory
    
    $file = fopen($filename, "w") or die("Unable to open file!");
    fwrite($file, $content);
    fclose($file);
}

// Function to create a new folder with input validation
function createFolder($foldername) {
    // Validate folder name to prevent directory traversal attacks
    $foldername = preg_replace('/[^A-Za-z0-9_.-]/', '', $foldername); // Remove any special characters
    $foldername = 'uploads/' . $foldername; // Assume uploads directory
    
    if (!file_exists($foldername)) {
        mkdir($foldername, 0777, true);
        echo "Folder created successfully!";
    } else {
        echo "Folder already exists!";
    }
}

// Handle actions based on the request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["action"])) {
        $action = $_POST["action"];
        
        // Handle saving file action
        if ($action === "save") {
            $filename = $_POST["filename"];
            $content = $_POST["content"];
            saveFile($filename, $content);
            echo "File saved successfully!";
        }
        
        // Handle creating folder action
        elseif ($action === "create_folder") {
            $foldername = $_POST["foldername"];
            createFolder($foldername);
        }
        
        // Add more actions as needed
    }
}

// Function to list files and folders
function listFilesFolders() {
    $files = glob('uploads/*');
    $output = '';
    foreach ($files as $file) {
        if (is_file($file)) {
            $output .= '<li><a href="' . $file . '">' . basename($file) . '</a></li>';
        } elseif (is_dir($file)) {
            $output .= '<li><a href="#">' . basename($file) . '</a></li>';
        }
    }
    echo $output;
}

// Display files and folders list
listFilesFolders();
?>