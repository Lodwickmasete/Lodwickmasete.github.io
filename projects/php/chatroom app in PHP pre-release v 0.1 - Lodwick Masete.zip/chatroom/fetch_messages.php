<?php
session_start();

// Include your database connection file
include 'config/db_conn.php';

// Check if the room ID is provided and valid
if (isset($_POST['room_id']) && !empty($_POST['room_id'])) {
    $room_id = $_POST['room_id']; 

    // SQL query to fetch messages
    $sql = "SELECT status, type, m.message_content, u.username, m.sent_at, u.profile_picture, m.message_id
            FROM Messages m
            JOIN Users u ON m.user_id = u.user_id
            WHERE m.room_id = '$room_id'
            ORDER BY m.sent_at ASC";
            
    $sql2 = "SELECT room_id FROM Chatrooms WHERE room_id = '$room_id'";

    $result = $conn->query($sql);
    $result2 = $conn->query($sql2);

    if ($result2->num_rows < 1) {
        // Room not found
        echo 'Room ' . $room_id . ' does not exist. You can <a href="create_room.php?room='.$room_id.'">create it</a>.';
        exit;
    }

    if ($result->num_rows > 0) {
        // Loop through results and populate the messages
        while($row = $result->fetch_assoc()) {
            $isUserMessage = ($_SESSION['username'] == $row['username']);
            $isDeleted = ($row['status'] == 'deleted');
            $avatarImage = $row['profile_picture'] 
                            ? '<img class="chat-image" src="' . $row['profile_picture'] . '" alt="Avatar">' 
                            : '<img class="chat-image" src="uploads/default_user_male.jpg" alt="Avatar">'; // Default if no profile pic

            if ($isUserMessage) {
                echo '<div class="message message-sent">';
                if ($isDeleted) {
                    echo '<p><i>You deleted this message</i></p>';
                } else {
                    if ($row['type'] == 'image') {
                        // Handle sent image
                        preg_match('/\*(.*?)\*/', $row['message_content'], $matches);
                        $mediaPath = $matches[1];
                        $caption = trim(str_replace('*' . $mediaPath . '*', '', $row['message_content']));

                        echo '<p><img src="' . $mediaPath . '" alt="Sent Image" class="chat-image chat-image-sent"><br>' . htmlspecialchars($caption) . '</p>';
                    } elseif ($row['type'] == 'audio') {
                        // Handle sent audio
                        preg_match('/\*(.*?)\*/', $row['message_content'], $matches);
                        $mediaPath = $matches[1];
                        $caption = trim(str_replace('*' . $mediaPath . '*', '', $row['message_content']));

                        echo '<div class="audio green-audio-player">
                                <audio src="' . $mediaPath . '"></audio>
                                <div class="play-pause-btn" onclick="togglePlay(this)">▶️</div>
                                <div class="controls">
                                    <span class="current-time">0:00</span>
                                    <div class="slider" onclick="seek(event, this)">
                                        <div class="progress">
                                            <div class="pin"></div>
                                        </div>
                                    </div>
                                    <span class="total-time">0:00</span>
                                </div>
                              </div>
                              <br>'.
                               //htmlspecialchars($caption) . 
                               '';
                    } else {
                        // Handle sent text
                        echo '<p>' . htmlspecialchars($row['message_content']) . '</p>';
                    }
                }
                echo '</div>';
            } else {
                echo '<div class="message message-received" data-reply-id="' . $row['message_id'] . '">';
                echo '<div class="avatar">' . $avatarImage . '</div>';
                if ($isDeleted) {
                    echo '<p><b>' . htmlspecialchars($row['username']) . '</b><br><i>This message was deleted</i></p>';
                } else {
                    echo '<p><b>' . htmlspecialchars($row['username']) . '</b><br>';
                    if ($row['type'] == 'image') {
                        // Handle received image
                        preg_match('/\*(.*?)\*/', $row['message_content'], $matches);
                        $mediaPath = $matches[1];
                        $caption = trim(str_replace('*' . $mediaPath . '*', '', $row['message_content']));

                        echo '<img src="' . $mediaPath . '" alt="Received Image" class="chat-image chat-image-recieved"><br>' . htmlspecialchars($caption);
                    } elseif ($row['type'] == 'audio') {
                        // Handle received audio
                        preg_match('/\*(.*?)\*/', $row['message_content'], $matches);
                        $mediaPath = $matches[1];
                        $caption = trim(str_replace('*' . $mediaPath . '*', '', $row['message_content']));

                        echo '
                        <div class="audio green-audio-player">
                                <audio src="' . $mediaPath . '"></audio>
                                <div class="play-pause-btn" onclick="togglePlay(this)">▶️</div>
                                <div class="controls">
                                    <span class="current-time">0:00</span>
                                    <div class="slider" onclick="seek(event, this)">
                                        <div class="progress">
                                            <div class="pin"></div>
                                        </div>
                                    </div>
                                    <span class="total-time">0:00</span>
                                </div>
                              </div>
                                                      </div>'
                            //   htmlspecialchars($caption)
                              ;
                    } else {
                        // Handle received text
                        echo htmlspecialchars($row['message_content']);
                    }
                    echo '';
                }
                echo '</div>';
            }
        }
    } else {
        echo '<center>No Messages Yet</center>';
        exit;
    }

    $conn->close();

} else {
    // Room ID is not provided or empty
    header("Location: create_room.php");
    exit;
}
?>