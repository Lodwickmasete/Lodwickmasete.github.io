// Function to toggle play/pause
function togglePlay(button) {
const audioPlayer = button.parentElement;
const audio = audioPlayer.querySelector('audio');
const isPlaying = !audio.paused;

// Pause all other audios
document.querySelectorAll('audio').forEach((aud) => {
aud.pause();
aud.currentTime = 0;
aud.parentElement.querySelector('.play-pause-btn').textContent = '▶️';
});

if (isPlaying) {
audio.pause();
button.textContent = '▶️';
} else {
audio.play();
button.textContent = '⏸️';
}

audio.ontimeupdate = function() {
const progress = audioPlayer.querySelector('.progress');
const currentTimeSpan = audioPlayer.querySelector('.current-time');
const totalTimeSpan = audioPlayer.querySelector('.total-time');

const currentTime = audio.currentTime;
const duration = audio.duration;
const progressWidth = (currentTime / duration) * 100;

progress.style.width = progressWidth + '%';

currentTimeSpan.textContent = formatTime(currentTime);
totalTimeSpan.textContent = formatTime(duration);
};
}

// Function to format time in minutes:seconds
function formatTime(time) {
const minutes = Math.floor(time / 60);
const seconds = Math.floor(time % 60);
return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
}

// Function to seek in the audio
function seek(event, slider) {
const audioPlayer = slider.closest('.green-audio-player');
const audio = audioPlayer.querySelector('audio');
const rect = slider.getBoundingClientRect();
const offsetX = event.clientX - rect.left;
const seekTime = (offsetX / rect.width) * audio.duration;    
// Set the current time of the audio
audio.currentTime = seekTime;
}