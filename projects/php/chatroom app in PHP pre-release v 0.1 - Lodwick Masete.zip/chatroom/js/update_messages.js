

     const chatContainer = document.querySelector('.chat-container');
     document.getElementById('send-button').addEventListener('click', function() {
    const messageInput = document.getElementById('message-input');
    const messageText = messageInput.value.trim();

    if (messageText !== "") {
        const chatContainer = document.querySelector('.chat-container');

        const newMessage = document.createElement('div');
        newMessage.classList.add('message', 'message-sent');
        newMessage.innerHTML = '<p>${messageText}</p>';

        chatContainer.appendChild(newMessage);
        messageInput.value = '';
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }
});


let lastMessageId = 1;

function fetchMessages() {
    const chatId = new URLSearchParams(window.location.search).get('chat_id');
    if (!chatId) {
        console.error('No chat ID specified.');
        return;
    }

    fetch(`../requests/fetch_last_message.php?chat_id=${chatId}&last_message_id=${lastMessageId}`)
        .then(response => response.json())
        .then(data => {
            if (data.id) {

                if (data.id > lastMessageId) {

                    const messageDiv = document.createElement('div');
                    messageDiv.classList.add('message', 'message-received');
                    messageDiv.innerHTML = `
                        <div class="avatar"><img src="./uploads/img/avatar1.png" alt="Avatar"></img></div>
                       <p>${data.content}
      <br>                 <span class="date">[${data.date}]</span>
                       </p>

                    `;

                    chatContainer.appendChild(messageDiv);
                    lastMessageId = data.id;
                    chatContainer.scrollTop = chatContainer.scrollHeight;
                }
            } else if (data.error) {
                console.error('Error:', data.error);
            }
        })
        .catch(error => console.error('Error fetching messages:', error));
}

// Fetch messages every 2 seconds
setInterval(fetchMessages, 2000);


const modal = document.getElementById("image-modal");
const modalImg = document.getElementById("img01");
const captionText = document.getElementById("caption");

document.querySelectorAll('.chat-image').forEach(img => {
    img.addEventListener('click', function() {
        modal.style.display = "block";
        modalImg.src = this.src;
        captionText.innerHTML = this.alt + '<div class="d-body">   <div class="icon-container"><svg class="download-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">    <path d="M12 2C11.4477 2 11 2.44772 11 3V13.5858L8.29289 10.8787C7.90237 10.4882 7.2692 10.4882 6.87868 10.8787C6.48816 11.2692 6.48816 11.9024 6.87868 12.2929L11.2929 16.7071C11.6834 17.0976 12.3166 17.0976 12.7071 16.7071L17.1213 12.2929C17.5118 11.9024 17.5118 11.2692 17.1213 10.8787C16.7308 10.4882 16.0976 10.4882 15.7071 10.8787L13 13.5858V3C13 2.44772 12.5523 2 12 2ZM4 18C4 17.4477 4.44772 17 5 17H19C19.5523 17 20 17.4477 20 18C20 18.5523 19.5523 19 19 19H5C4.44772 19 4 18.5523 4 18Z"/>        </svg>     </div>   </div>';
    });
});

const span = document.getElementsByClassName("close")[0];
span.onclick = function() { 
    modal.style.display = "none";
}