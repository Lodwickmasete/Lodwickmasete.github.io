-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 31, 2024 at 05:01 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chatroom`
--

-- --------------------------------------------------------

--
-- Table structure for table `Chatrooms`
--

CREATE TABLE `Chatrooms` (
  `room_id` int(11) NOT NULL,
  `room_name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `is_private` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Chatrooms`
--

INSERT INTO `Chatrooms` (`room_id`, `room_name`, `description`, `is_private`, `created_at`) VALUES
(12345, 'Sekgalabjana', NULL, 0, '2024-08-10 20:01:49'),
(19816, 'Damn', NULL, 0, '2024-08-11 11:55:36'),
(20798, 'Damn', NULL, 0, '2024-08-11 00:39:53'),
(32273, 'Damn', NULL, 0, '2024-08-11 00:42:47'),
(49193, 'JBL', NULL, 0, '2024-08-25 12:49:58'),
(65649, '6777', NULL, 0, '2024-08-11 08:53:47'),
(67567, 'Massts', NULL, 0, '2024-08-25 12:53:54'),
(75167, 'Mad in china', NULL, 0, '2024-08-10 20:18:51'),
(78785, 'Try', NULL, 0, '2024-08-11 08:50:18'),
(88888, 'Tomorrow', NULL, 0, '2024-08-10 20:20:42'),
(91930, 'MAswfe', NULL, 0, '2024-08-11 08:49:18'),
(98989, 'Statement', NULL, 0, '2024-08-25 12:57:13');

-- --------------------------------------------------------

--
-- Table structure for table `Messages`
--

CREATE TABLE `Messages` (
  `message_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `message_content` text NOT NULL,
  `type` text DEFAULT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'active',
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Messages`
--

INSERT INTO `Messages` (`message_id`, `user_id`, `room_id`, `message_content`, `type`, `status`, `sent_at`) VALUES
(1, 5, 12345, '*http://0.0.0.0:8080/uploads/audio/1.mp3*', 'audio', 'active', '2024-08-25 13:01:18'),
(2, 5, 12345, '*http://0.0.0.0:8080/uploads/audio/2.mp3*kksow', 'audio', 'active', '2024-08-25 13:01:18'),
(1007, 5, 12345, '*http://0.0.0.0:8080/uploads/img/0720261036.png*', 'image', 'active', '2024-08-25 13:01:18'),
(1008, 5, 12345, '*http://0.0.0.0:8080/uploads/img/4.png*', 'image', 'active', '2024-08-25 13:01:18'),
(1009, 5, 12345, '*http://0.0.0.0:8080/uploads/img/4.png*', 'image', 'active', '2024-08-25 13:01:18'),
(1010, 5, 12345, 'Hi', NULL, 'active', '2024-08-25 13:33:05'),
(1011, 5, 12345, 'Hi', NULL, 'active', '2024-08-25 13:33:05'),
(1012, 5, 49193, '*http://0.0.0.0:8080/uploads/img/4.png*', 'image', 'active', '2024-08-25 13:01:18'),
(1013, 5, 12345, '*http://0.0.0.0:8080/uploads/img/4.png*', 'image', 'active', '2024-08-25 13:01:18');

-- --------------------------------------------------------

--
-- Table structure for table `Room_Members`
--

CREATE TABLE `Room_Members` (
  `member_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `role` varchar(50) DEFAULT 'member'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Room_Members`
--

INSERT INTO `Room_Members` (`member_id`, `user_id`, `room_id`, `joined_at`, `role`) VALUES
(39, 2, 12345, '2024-08-10 20:01:49', 'admin'),
(40, 5, 75167, '2024-08-10 20:18:51', 'admin'),
(41, 5, 88888, '2024-08-10 20:20:42', 'admin'),
(42, 5, 20798, '2024-08-11 00:39:53', 'admin'),
(43, 5, 32273, '2024-08-11 00:42:47', 'admin'),
(44, 5, 91930, '2024-08-11 08:49:18', 'admin'),
(45, 5, 78785, '2024-08-11 08:50:18', 'admin'),
(46, 5, 65649, '2024-08-11 08:53:47', 'admin'),
(47, 5, 49193, '2024-08-25 12:49:58', 'admin'),
(48, 5, 67567, '2024-08-25 12:53:54', 'admin'),
(49, 5, 98989, '2024-08-25 12:57:13', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(250) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`user_id`, `username`, `password`, `email`, `phone`, `profile_picture`, `created_at`) VALUES
(1, 'user1', '1111', 'user1@example.com', NULL, 'uploads/img/1.png', '2024-08-08 19:26:39'),
(2, 'user2', '2222', 'user2@example.com', NULL, 'uploads/img/2.png', '2024-08-08 19:26:39'),
(3, 'user3', '3333', 'user3@example.com', NULL, 'uploads/img/3.png', '2024-08-08 19:26:39'),
(5, 'Lodwick', '1234', 'lodwickjmasete@gmail.com', '0720261036', 'uploads/img/2.png', '2024-08-09 07:58:25'),
(6, '1234', '1234', 'a@gmail.com', '1234567890', '', '2024-08-10 17:40:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Chatrooms`
--
ALTER TABLE `Chatrooms`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `Messages`
--
ALTER TABLE `Messages`
  ADD PRIMARY KEY (`message_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `Room_Members`
--
ALTER TABLE `Room_Members`
  ADD PRIMARY KEY (`member_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Chatrooms`
--
ALTER TABLE `Chatrooms`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98990;

--
-- AUTO_INCREMENT for table `Messages`
--
ALTER TABLE `Messages`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1014;

--
-- AUTO_INCREMENT for table `Room_Members`
--
ALTER TABLE `Room_Members`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Messages`
--
ALTER TABLE `Messages`
  ADD CONSTRAINT `Messages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `Users` (`user_id`),
  ADD CONSTRAINT `Messages_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `Chatrooms` (`room_id`);

--
-- Constraints for table `Room_Members`
--
ALTER TABLE `Room_Members`
  ADD CONSTRAINT `Room_Members_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `Users` (`user_id`),
  ADD CONSTRAINT `Room_Members_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `Chatrooms` (`room_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
