<?php include 'config/header.php'; ?>

    <title>Create Room</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #f4f4f4;
        }

        form {
            background-color: #fff;
            padding: 30px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            width: 350px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 3px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>

<body>
    <form action="config/process_room_creation.php" method="post">
        <h2>Create Chat Room</h2>
        <label for="room_name">Room Name:</label>
        <input type="text" id="room_name" name="room_name" required>
        <input type="text" id="room_id" name="room_id" value="<?php    
        if (isset($_GET['room'])) {
        $room_id = $_GET['room'];
        if (!preg_match('/^\d{5}$/', $room_id)) {
        //do nothing
        }else{
        echo $room_id;
        }
        }  ?>" hidden>
        <input type="submit" value="Create Room">
    </form>
</body>
</html>