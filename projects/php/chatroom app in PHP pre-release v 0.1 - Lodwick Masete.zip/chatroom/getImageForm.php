

<style>
form {
    width: 300px;
    padding: 20px;
    margin-left:5px;
    border-radius: 8px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    background: linear-gradient(to right, #3498db, #6c5b7b);
    color: #fff;
    text-align: center;

}

.form-control {
    width: calc(100% - 20px);
    padding: 10px;
    margin-top: 10px;
    border: none;
    border-radius: 5px;
    background-color: rgba(255, 255, 255, 0.8);
    transition: background-color 0.3s;
}

.form-control:focus {
    background-color: #fff;
}

.image-input-container {
    margin-bottom: 10px;
}

.add-more-button {
    width: 100%;
    padding: 7px;
    background-color: #2ecc71;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
}

</style>


<form id="uploadForm" method="post" enctype="multipart/form-data">

    <div id="file-inputs">
        <div class="file-input-container">
            <input type="text" name="room_id" value="<?php echo $_POST['room_id']; ?>" hidden>
            <input type="file" name="file[]" accept="" class="form-control">
        </div>
    </div>   

    <b class="add-more-button" onclick="addFileInput()">+</b>
    <b class="submit-button" onclick="submitForm()">Submit</b>
</form>

<script>
    function addFileInput() {
        const container = document.createElement('div');
        container.className = 'file-input-container';
        
        const input = document.createElement('input');
        input.type = 'file';
        input.name = 'file[]';
        input.className = 'form-control';
        
        container.appendChild(input);
        document.getElementById('file-inputs').appendChild(container);
    }

    function submitForm() {
        document.getElementById('uploadForm').submit();
    }
</script>