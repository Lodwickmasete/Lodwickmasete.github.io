<?php
session_start();

// Include your database connection file
include '../config/db_conn.php';

// Check if the user is logged in and is an admin of the room
if (isset($_SESSION['username']) && isset($_GET['room_id'])) {
    $username = $_SESSION['username'];
    $room_id = $_GET['room_id'];

    // Get room details
    $sql = "SELECT room_name FROM Chatrooms WHERE room_id = '$room_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $room_name = $row['room_name'];

        // Get member count
        $sql = "SELECT COUNT(*) AS member_count FROM Room_Members WHERE room_id = '$room_id'";
        $member_count_result = $conn->query($sql);
        $member_count_row = $member_count_result->fetch_assoc();
        $member_count = $member_count_row['member_count'];

        // Get member names
        $sql = "SELECT u.username FROM Users u 
                JOIN Room_Members rm ON u.user_id = rm.user_id
                WHERE rm.room_id = '$room_id'";
        $member_names_result = $conn->query($sql);

        // Check if the current user is an admin of the room
        $sql = "SELECT role FROM Room_Members WHERE room_id = '$room_id' AND user_id = (SELECT user_id FROM Users WHERE username = '$username')";
        $admin_check_result = $conn->query($sql);

        if ($admin_check_result->num_rows > 0) {
            $admin_check_row = $admin_check_result->fetch_assoc();
            if ($admin_check_row['role'] === 'admin') {
                // Display room details
                ?>
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Room Details</title>
                </head>
                <body>
                    <h2>Room: <?php echo $room_name; ?></h2>
                    <p>Member Count: <?php echo $member_count; ?></p>

                    <h3>Members:</h3>
                    <ul>
                        <?php
                        if ($member_names_result->num_rows > 0) {
                            while ($member_row = $member_names_result->fetch_assoc()) {
                                echo "<li>" . $member_row['username'] . "</li>";
                            }
                        } else {
                            echo "<li>No members yet.</li>";
                        }
                        ?>
                    </ul>
                </body>
                </html>
                <?php
            } else {
                // User is not an admin
                echo "You are not authorized to view room details.<b>Only admin Can</b>";
            }
        } else {
            // User is not an admin
            echo "You are not authorized to view room details. <b>Only admin Can</b>";
        }

    } else {
        // Room not found
        echo "Room not found.";
    }

    $conn->close();

} else {
    // User not logged in or room ID not provided
    echo "Please log in and provide a valid room ID.";
}