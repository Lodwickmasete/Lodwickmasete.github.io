<style>
a{
text-decoration:none;

}

</style>

<?php

include 'db_conn.php';

// Get chatroom ID from POST data
$room_id = $_POST['room_id'];

// SQL query to fetch chatroom details
$sql = "SELECT c.room_name, c.description, 
               GROUP_CONCAT(u.username) AS members
        FROM Chatrooms c
        JOIN Room_Members rm ON c.room_id = rm.room_id
        JOIN Users u ON rm.user_id = u.user_id
        WHERE c.room_id = '$room_id'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $roomName = $row['room_name'];
    $roomDescription = $row['description'];
    $roomMembers = explode(',', $row['members']); // Get member usernames as an array

    // Get member count (excluding the current user)
    $memberCount = count($roomMembers) - 1;

    // Format members string
    $membersString = '';
    for ($i = 0; $i < min(3, $memberCount); $i++) {
        $membersString .= $roomMembers[$i];
        if ($i < $memberCount - 1 && $i < 2) {
            $membersString .= ', ';
        } else if ($i < $memberCount - 1) {
            $membersString .= ' and ';
        }
    }
    if ($memberCount > 3) {
        $membersString .= ' and ' . ($memberCount - 3) . ' others';
    }

    // Output the HTML
    echo '<div class="top-bar">';
    echo ' <div class="top-bar-avatar">';
    echo '    <img src="../uploads/img/5.png" alt="group default Avatar">';
    echo ' </div>';
    
    echo '<div class="top-bar-info" onclick="roomDetails('. "'". $room_id . "'" .')">';
    echo '    <div class="top-bar-name">' . $roomName . '</div>';
    echo '    <div class="top-bar-phone members">' . $membersString . '</div>';
    echo ' </div>';

    echo '</div>';

} else {
    echo "Chatroom not found.";
}

$conn->close();
?>

<script>
  function roomDetails(r){
  window.location.href ="../rooms/room_details.php?room_id="+ r;  
  }

</script>