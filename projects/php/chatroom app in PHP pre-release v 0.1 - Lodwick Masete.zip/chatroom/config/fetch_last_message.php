<?php
if (isset($_GET['chat_id']) && isset($_GET['last_message_id'])) {
    $chat_id = basename($_GET['chat_id']);
    $last_message_id = intval($_GET['last_message_id']);
    $chat_file = __DIR__ . '/../db/chats/' . $chat_id . '.txt'; // Correct path concatenation

    if (file_exists($chat_file)) {
        $chat_content = file($chat_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $last_message = null;

        foreach ($chat_content as $line) {
            list($sender, $date, $message_id, $message,) = explode('][', trim($line, '[]'));
            $message_id = intval($message_id);
            
            if ($message_id > $last_message_id) {
                $last_message = [
                    'id' => htmlspecialchars($message_id, ENT_QUOTES, 'UTF-8'),
                    'sender' => htmlspecialchars($sender, ENT_QUOTES, 'UTF-8'),
                    'date' => htmlspecialchars($date, ENT_QUOTES, 'UTF-8'),
                    'content' => htmlspecialchars($message, ENT_QUOTES, 'UTF-8'),

                ];

        }

        header('Content-Type: application/json');

        if ($last_message) {
            echo json_encode($last_message);
        } else {
            echo json_encode(['error' => 'No new messages.']);
        }
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'Chat file not found.']);
    }
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid request.']);
}
?>