<?php
session_start(); 

// Include your database connection file
include 'db_conn.php'; 

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Retrieve data from the form
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    // Validate input (add more validation as needed)
    if (empty($username) || empty($password) || empty($email) || empty($phone)) {
        echo "Please fill in all fields.";
        exit;
    }

    // Sanitize input to prevent SQL injection
    $username = mysqli_real_escape_string($conn, $username);
    $password = mysqli_real_escape_string($conn, $password);
    $email = mysqli_real_escape_string($conn, $email);
    $phone = mysqli_real_escape_string($conn, $phone);

    // Check if username already exists
    $sql = "SELECT user_id FROM Users WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "Username already exists.";
        exit;
    }

    // Hash the password before storing it
    $hashedPassword = $password;

    // Upload Profile Image (if provided)
    $profile_img_path = null;
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        // Get the temporary file name
        $tmp_name = $_FILES['profile_picture']['tmp_name'];
        // Generate a unique file name
        $file_name = uniqid() . '_' . basename($_FILES['profile_picture']['name']);
        // Specify the upload directory (adjust this as needed)
        $upload_dir = '../uploads/img';
        $target_file = $upload_dir . $file_name;
        // Move the uploaded file
        if (move_uploaded_file($tmp_name, $target_file)) {
            $profile_img_path = $target_file; // Store the image path
        } else {
            echo "Error uploading profile image.";
            exit;
        }
    }

    // SQL query to insert the new user into the database
    $sql = "INSERT INTO Users (username, password, email, phone, profile_picture) 
            VALUES ('$username', '$hashedPassword', '$email', '$phone', '$profile_img_path')";

    if ($conn->query($sql) === TRUE) {
        echo "Registration successful! You can now log in.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Signup</title>
</head>
<body>
    <?php if (isset($_SESSION['username'])) : ?>
        <p>You are already logged in as      <?php echo $_SESSION['username'] ?>.</p>
        <a href="../indexPage.php">Go to Chat</a>
    <?php else : ?>
        <form action="signup.php" method="post" enctype="multipart/form-data">
            <h2>Signup Form</h2>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="phone">Phone Number:</label>
            <input type="text" id="phone" name="phone" required>

            <label for="profile_picture">Profile Image:</label>
            <input type="file" id="profile_img" name="profile_picture" accept="image/*" required>

            <input type="submit" value="Submit">
        </form>
    <?php endif; ?>
</body>
</html>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }
    h2 {
        text-align: center;
        color: #333;
    }
    form {
        background-color: #fff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 400px;
    }
    label {
        display: block;
        margin-bottom: 8px;
        color: #555;
    }
    input[type="text"],
    input[type="password"],
    input[type="email"],
    input[type="file"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
    }
    input[type="submit"] {
        width: 100%;
        background-color: #007bff;
        color: white;
        padding: 10px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }
    input[type="submit"]:hover {
        background-color: #0056b3;
    }
</style>