<?php
session_start();
include 'db_conn.php';
?>
<?php
if (!isset($_SESSION['username'])) {
header("Location: config/login.php");
    exit();
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
<style type="text/css">


.loader {
    border: 8px solid #f3f3f3; /* Light gray */
    border-top: 8px solid #3498db; /* Blue */
    border-radius: 50%;
    width: 60px;
    height: 60px;
    animation: spin 2s linear infinite; /* Spin animation */
    
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

</style>



    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat Message Cloud</title>
      <link rel="stylesheet" href="./css/chat.css">
      <link rel="stylesheet" href="./css/audijo.css">
</head>