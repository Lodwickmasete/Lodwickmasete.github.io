<?php
session_start(); // Start the session

// Include database connection file
include 'db_conn.php';

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the message, room_id, and username from the POST data
    $message = $_POST['message'];
    $room_id = $_POST['room_id'];
    $username = $_SESSION['username'];

    // Escape the message to prevent SQL injection
    $message = mysqli_real_escape_string($conn, $message); 

    // SQL query to insert the message into the database
    $sql = "INSERT INTO Messages (user_id, room_id, message_content, sent_at) 
            VALUES ((SELECT user_id FROM Users WHERE username = '$username'), '$room_id', '$message', NOW())";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        // Message successfully inserted
        echo json_encode(['status' => 'success', 'message' => 'Message sent successfully.']);
    } else {
        // Error inserting message
        echo json_encode(['status' => 'error', 'message' => 'Error sending message: ' . $conn->error]);
    }

    $conn->close();
} else {
    // Not a POST request
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
}
?>