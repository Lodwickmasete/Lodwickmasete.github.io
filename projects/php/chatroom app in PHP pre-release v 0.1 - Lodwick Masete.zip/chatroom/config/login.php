<?php
session_start(); // Start the session

// Include your database connection file
include 'db_conn.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the username and password from the form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Sanitize input to prevent SQL injection
    $username = mysqli_real_escape_string($conn, $username);
    $password = mysqli_real_escape_string($conn, $password);




    // SQL query to fetch the user's information based on username
    $sql = "SELECT user_id, password FROM Users WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // User exists
        $row = $result->fetch_assoc();
        $storedPassword = $row['password'];

        // Verify the password using password_verify
        if ($password == $storedPassword) {
            // Password matches
            $_SESSION['username'] = $username; // Set the session variable
            header("Location: ../indexPage.php"); // Redirect to the chat page
            exit();
        } else {
            // Invalid password
            $error = "Invalid username or password.";
        }
    } else {
        // User does not exist
        $error = "Invalid username or password.";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>

    <form action="login.php" method="post">
        <h2>Login Form</h2>

        <label for="username">Username:</label>
        <input type="text" id="username" name="username" value="Lodwick" required>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" value="1234" required>
<?php if (isset($error)) : ?>
   <br> <div style="color: red;"><?php echo $error; ?></div><br>
<?php endif; ?>
        <input type="submit" value="Login">
        
        
    </form>
</body>
</html>


<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }
    h2 {
        text-align: center;
        color: #333;
    }
    form {
        background-color: #fff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 400px;
    }
    label {
        display: block;
        margin-bottom: 8px;
        color: #555;
    }
    input[type="text"],
    input[type="password"],
    input[type="email"],
    input[type="file"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
    }
    input[type="submit"] {
        width: 100%;
        background-color: #007bff;
        color: white;
        padding: 10px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }
    input[type="submit"]:hover {
        background-color: #0056b3;
    }
</style>