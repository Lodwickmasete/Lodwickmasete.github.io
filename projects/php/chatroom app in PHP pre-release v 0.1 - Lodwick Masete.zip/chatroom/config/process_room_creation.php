<?php
session_start();

// Include your database connection file
include 'db_conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the room name from the form
    $room_name = $_POST['room_name'];

    // Sanitize input to prevent SQL injection
    $room_name = mysqli_real_escape_string($conn, $room_name);


if (isset($_POST['room_id']) && preg_match('/^\d{5}$/', $_POST['room_id'])) {
    $prefered_room_id = $_POST['room_id'];
    $room_id = $prefered_room_id;
}
else {
// Generate a random 5-digit room ID
$room_id = rand(10000, 99999);
}


    // Check if the room ID already exists (optional, but recommended for uniqueness)
    $sql = "SELECT room_id FROM Chatrooms WHERE room_id = '$room_id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0 ) {
        // If the room ID exists, regenerate it until it's unique
        $room_id = rand(10000, 99999);
    }

    // Insert the new room into the database
    $sql = "INSERT INTO Chatrooms (room_id, room_name) VALUES ('$room_id', '$room_name')";
    if ($conn->query($sql) === TRUE) {
        // Room created successfully, now add the creator as admin
        $username = $_SESSION['username']; // Assuming you're storing the username in the session

        // Get the user ID from the Users table
        $sql = "SELECT user_id FROM Users WHERE username = '$username'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $user_id = $row['user_id'];

            // Insert the creator as admin into the Room_Members table
            $sql = "INSERT INTO Room_Members (room_id, user_id, role) VALUES ('$room_id', '$user_id', 'admin')";
            if ($conn->query($sql) === TRUE) {
                // Room member added successfully
                $conn->close();

                // Display the room ID and a copy button
                ?>
                <!DOCTYPE html>
                <html>
                <head>
                <title>Chat Message Cloud</title>

  
                    <title> <?php echo $room_name;?> Room Created</title>

                </head>
                <body>
                    <h2>Room Created!</h2>
                    Your room ID is: <input type="text" id="room_id" value="<?php echo $room_id; ?>" readonly>
                      <br>Share this ID with others to join the chatroom<br>      
                    <button onclick="copyRoomId()">Copy Room ID</button>
              <br>
                <form action="../chat.php" method="POST">

                <input type="text" id="room_id" name="room_id" value="<?php echo $room_id; ?>" hidden>                
                <input type="submit" value="Continue to Chat">
                </form>
                <script>
                    function copyRoomId() {
                        // Get the room ID from the input field
                        var roomId = document.getElementById('room_id').value;
                        // Copy the room ID to the clipboard
                        navigator.clipboard.writeText(roomId)
                            .then(() => {
                                // Display a success message
                                alert('Room ID copied to clipboard!');
                            })
                            .catch(err => {
                                console.error('Failed to copy: ', err);
                                alert('Failed to copy room ID.');
                            });
                    }
                </script>
                </body>
                </html>
                <?php
            } else {
                // Error adding the room member
                echo "Error adding room member: " . $conn->error;
            }
        } else {
            // User not found
            echo "User not found.";
        }
    } else {
        // Error creating the room
        echo "Error creating room: " . $conn->error;
    }
}
?>