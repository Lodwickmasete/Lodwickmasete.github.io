<?php
session_start(); // Start the session

// Include database connection file
include 'db_conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uploadDir = 'uploads/files/';  // Change directory for other files
    $uploadedFiles = [];

    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    if (!empty($_FILES['file']['name'][0])) {
        $total = count($_FILES['file']['name']);
        
        // Check if username is set in session
        if (!isset($_SESSION['username'])) {
            echo json_encode(['status' => 'error', 'message' => 'User not logged in.']);
            exit;
        }

        $username = $_SESSION['username'];
        $room_id = $_POST['room_id'];

        for ($i = 0; $i < $total; $i++) {
            $tempFile = $_FILES['file']['tmp_name'][$i];
            $filename = sprintf('%04d', $i + 1) . '_' . basename($_FILES['file']['name'][$i]);
            $targetFile = $uploadDir . $filename;

            // Optionally, validate the file type (e.g., only allow certain file extensions)
            $fileType = pathinfo($targetFile, PATHINFO_EXTENSION);
            $allowedTypes = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'txt']; // Add more if needed

            if (in_array(strtolower($fileType), $allowedTypes)) {
                if (move_uploaded_file($tempFile, $targetFile)) {
                    $uploadedFiles[] = $targetFile;

                    $message = '*' . $filename . '*';

                    // Escape the message to prevent SQL injection
                    $message = mysqli_real_escape_string($conn, $message);

                    // SQL query to insert each file as a separate message
                    $sql = "INSERT INTO Messages (user_id, room_id, message_content, sent_at) 
                            VALUES ((SELECT user_id FROM Users WHERE username = '$username'), '$room_id', '$message', NOW())";

                    // Execute the query
                    if ($conn->query($sql) !== TRUE) {
                        // Error inserting message
                        echo json_encode(['status' => 'error', 'message' => 'Error sending message: ' . $conn->error]);
                        exit;
                    }
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Invalid file type: ' . $fileType]);
                exit;
            }
        }

        // Message successfully inserted
        echo json_encode(['status' => 'success', 'message' => 'Files uploaded and messages sent successfully.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No files uploaded.']);
    }

    $conn->close();
}
?>