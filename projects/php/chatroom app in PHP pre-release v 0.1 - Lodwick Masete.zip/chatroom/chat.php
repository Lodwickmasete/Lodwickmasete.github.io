<?php include 'config/header.php'; ?>
<body>
<style type="text/css">


  .audio.green-audio-player {
    width: 400px;
    margin-top: 40px;
   margin-left: -75px;
    min-width: 300px;
    height: 56px;
    box-shadow: 0 4px 16px 0 rgba(0, 0, 0, 0.07);
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-left: 24px;
    padding-right: 24px;
    border-radius: 4px;
    user-select: none;
    -webkit-user-select: none;
    background-color: white;

  }
  .audio.green-audio-player .play-pause-btn {
    cursor: pointer;
  }
  .audio.green-audio-player .spinner {
    width: 18px;
    height: 18px;
    background-image: url(../img/loading.png);
    background-size: cover;
    background-repeat: no-repeat;
    animation: spin 0.4s linear infinite;
  }
  .audio.green-audio-player .slider {
    flex-grow: 1;
    background-color: #D8D8D8;
    cursor: pointer;
    position: relative;
  }
  .audio.green-audio-player .slider .progress {
    background-color: #44BFA3;
    border-radius: inherit;
    position: absolute;
    pointer-events: none;
    height: 100%;
    width: 0;
  }
  .audio.green-audio-player .slider .progress .pin {
    height: 16px;
    width: 16px;
    border-radius: 8px;
    background-color: #44BFA3;
    position: absolute;
    pointer-events: all;
    right: -8px;
    top: -6px;
    box-shadow: 0px 1px 1px 0px rgba(0, 0, 0, 0.32);
  }
  .audio.green-audio-player .controls {
    font-family: "Roboto", sans-serif;
    font-size: 16px;
    line-height: 18px;
    color: #55606E;
    display: flex;
    flex-grow: 1;
    justify-content: space-between;
    align-items: center;
    margin-left: 24px;
    margin-right: 24px;
  }
  .audio.green-audio-player .controls .slider {
    margin-left: 16px;
    margin-right: 16px;
    border-radius: 2px;
    height: 4px;
  }
  .audio.green-audio-player .controls span {
    cursor: default;
  }
  .audio.green-audio-player .volume {
    position: relative;
  }
  .audio.green-audio-player .volume .volume-btn {
    cursor: pointer;
  }
  .audio.green-audio-player .volume .volume-btn.open path {
    fill: #44BFA3;
  }
  .audio.green-audio-player .volume .volume-controls {
    width: 30px;
    height: 135px;
    background-color: rgba(0, 0, 0, 0.62);
    border-radius: 7px;
    position: absolute;
    left: -3px;
    bottom: 52px;
    flex-direction: column;
    align-items: center;
    display: flex;
  }
  .audio.green-audio-player .volume .volume-controls.hidden {
    display: none;
  }
  .audio.green-audio-player .volume .volume-controls .slider {
    margin-top: 12px;
    margin-bottom: 12px;
    width: 6px;
    border-radius: 3px;
  }
  .audio.green-audio-player .volume .volume-controls .slider .progress {
    bottom: 0;
    height: 100%;
    width: 6px;
  }
  .audio.green-audio-player .volume .volume-controls .slider .progress .pin {
    left: -5px;
    top: -8px;
  }

  @keyframes spin {
    from {
      transform: rotateZ(0);
    }
    to {
      transform: rotateZ(1turn);
    }
  }
</style>

<?php 
if (!isset($_POST['room_id'])) {
echo '<style type="text/css"> .loader { border: 8px solid #f3f3f3; border-top: 8px solid #3498db; border-radius: 50%; width: 60px; height: 60px; animation: spin 2s linear infinite; } @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } } </style><center><div class="loader" id="loader"></div></center>';
    exit();
}
$room_id= $_POST['room_id'];
if (!preg_match('/^\d{5}$/', $room_id)) {
    die('Room id consists of 5 digits');
}
$_SESSION['lastmessageid'][$room_id] = 0;

?>
<?php
include 'config/room_top_bar.php';
?>
    <div id="chat-container" class="chat-container">

    </div>
<div class="input-container">
    <div id="image-form">    </div>
    <input oninput="toggleSendButton()" type="text" placeholder="Type a message" id="message-input">
    <button onclick="getImageForm()"  id="send-button">Img</button>
</div>





    <?php include 'image_Viewer.html'; ?>  
</body>
<script>
function toggleSendButton() {
    var input = document.getElementById("message-input").value; // Use lowercase 'input'
    var sendButton = document.getElementById("send-button");

    if (input.trim() === "") {
        sendButton.textContent = "Img";
        sendButton.onclick = getImageForm; // Assuming getImageForm is defined elsewhere
    } else {
        sendButton.textContent = "Send";
        sendButton.onclick = sendMessage; // Assuming sendMessage is defined elsewhere
    }
}

function getImageForm(){

        var imageForm = document.getElementById('image-form');
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                imageForm.innerHTML = this.responseText ;
            }

        };
        xhttp.open("POST", "getImageForm.php", true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send("room_id=<?php echo $room_id;?>;");
        chatBox.scrollTop = chatBox.scrollHeight;
        document.getElementById("user-input").value = "Share";

     document.getElementById("send-message").innerHTML ="send";
}

function share(){
    var formData = new FormData(document.getElementById('uploadForm'));
    const displayArea = document.getElementById('chat-box'); // Assuming you have a 'chat-box' div to display responses
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'upload.php', true);

    // Add the textarea value to the FormData
    formData.append('message', document.getElementById('message-input').value); 

    xhr.onload = function() {
        if (xhr.status === 200) {
alert(xhr.responseText);

        }
    };
    xhr.send(formData);
}
</script>
    <script>

        const roomId = <?php echo $room_id;?>;
        const chatBox = document.getElementById("chat-container");
        chatBox.innerHTML ='<center><div class="loader" id="loader"></div></center>';
function LoadRoom() {
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            // Check if the response is "No New Messages"
            if (this.responseText.trim() === '<center>No New Messages</center>') {
                return; // Do not scroll or append anything if there are no new messages
            }
            // Create a temporary div to hold the new messages
            var tempDiv = document.createElement("div");
            tempDiv.innerHTML = this.responseText;

            // Append new messages to the chat box
            while (tempDiv.firstChild) {
                chatBox.appendChild(tempDiv.firstChild);
            }

            // Scroll to the bottom of the chat box
            chatBox.scrollTop = chatBox.scrollHeight;
        }
    };

    xhttp.open("POST", "f.php", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send("room_id=" + encodeURIComponent(roomId));
}


</script>

            <script>
            
            //_/////////
            
// Function to send a new message
function sendMessage(roomId) {
const messageInput = document.getElementById('message-input');
const messageText = messageInput.value;

if (messageText.trim() !== '') {
fetch('config/send_message.php', {
method: 'POST',
headers: {
'Content-Type': 'application/x-www-form-urlencoded'
},
body: `room_id=<?php echo $room_id;?>&message=${encodeURIComponent(messageText)}` 
})
.then(response => response.json())
.then(data => {
if (data.status === 'success') {
// Message sent successfully
messageInput.value = '';
LoadRoom(<?php echo $room_id;?>); // Reload messages
} else {
// Error sending message
console.error('Error sending message:', data.message);
}
})
.catch(error => console.error('Error sending message:', error));
}
}
            
            // Event listener for the send button
            const sendButton = document.getElementById('send-button');
            sendButton.addEventListener('click', () => sendMessage(roomId));
            
           
            setTimeout(function() { // Add a delay
            chatBox.innerHTML ='';
            LoadRoom();

            }, 1000);

          setInterval(LoadRoom, 1000);



    </script>
    <script>
    <?php include 'js/audioPlayer.js'; ?>  
    
    </script>

    </body>
    </html>