<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include 'db_conn.php';

$username = $_SESSION['username'];

// Prepare the SQL query
$sql = "SELECT r.room_id, r.room_name 
        FROM Chatrooms r 
        JOIN Users u ON r.user_id = u.user_id 
        WHERE u.username = ?";
$stmt = $conn->prepare($sql);

// Check if prepare was successful
if (!$stmt) {
    die('Prepare failed: ' . $conn->error);
}

// Bind parameters
$stmt->bind_param("s", $username);

// Execute the query
if (!$stmt->execute()) {
    die('Execute failed: ' . $stmt->error);
}

// Get the result
$result = $stmt->get_result();

// Fetch all rooms
$rooms = $result->fetch_all(MYSQLI_ASSOC);

// Close the statement
$stmt->close();

// Close the connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat Rooms</title>
    <link href="path/to/tailwind.css" rel="stylesheet">
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">

    <div class="w-full max-w-lg p-6 bg-white shadow-md rounded-lg">
        <h2 class="text-2xl font-bold mb-4">Select a Room</h2>
        
        <!-- Room List -->
        <div id="room-list" class="mb-4">
            <?php if ($rooms): ?>
                <ul class="list-disc pl-5">
                    <?php foreach ($rooms as $room): ?>
                        <li class="mb-2">
                            <form action="chat.php" method="POST" class="inline">
                                <input type="hidden" name="room_id" value="<?php echo htmlspecialchars($room['room_id']); ?>">
                                <button type="submit" class="text-blue-500 hover:underline"><?php echo htmlspecialchars($room['room_name']); ?></button>
                            </form>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p class="text-gray-500">No rooms available.</p>
            <?php endif; ?>
        </div>

        <!-- Manual Room ID Form -->
        <div id="manual-room-form">
            <h2 class="text-xl font-bold mb-4">Enter Room ID</h2>
            <form action="chat.php" method="POST">
                <label for="room_id" class="block text-gray-700">Room ID:</label>
                <input type="text" id="room_id" name="room_id" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                <input type="submit" value="Continue to Chat" class="mt-4 bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600">
            </form>
            <p class="mt-4 text-gray-600">
                or
                <a href="create_room.php" class="text-blue-500 hover:underline">Create Room</a>
            </p>
        </div>

        <button id="toggle-button" class="mt-4 bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600">Toggle Room Form</button>
    </div>

    <script>
        document.getElementById('toggle-button').addEventListener('click', function() {
            const roomList = document.getElementById('room-list');
            const manualRoomForm = document.getElementById('manual-room-form');
            if (roomList.style.display === 'none') {
                roomList.style.display = 'block';
                manualRoomForm.style.display = 'none';
                this.textContent = 'Show Room Form';
            } else {
                roomList.style.display = 'none';
                manualRoomForm.style.display = 'block';
                this.textContent = 'Show Room List';
            }
        });

        // Initialize visibility
        document.getElementById('room-list').style.display = 'block';
        document.getElementById('manual-room-form').style.display = 'none';
    </script>
</body>
</html>